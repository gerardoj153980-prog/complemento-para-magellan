# -*- coding: utf-8 -*-
"""Carga y lectura del catálogo Magellan y sus listas dependientes.

Conserva el orden de los documentos, sigue externallink de carpetas y no
combina fuentes entre canales. Admite el envoltorio GZIP/hex de Magellan y M3U.
"""
from __future__ import absolute_import, unicode_literals

import gzip
import base64
import hashlib
import html
import re
import unicodedata
import json
import warnings
import urllib.request
import urllib.parse
import xml.etree.ElementTree as ET

CATALOG_URL = 'https://gitlab.com/afonsocosta/magellan_matrix/-/raw/main/magellan.txt'
MAGELLAN_MARKER = 'tbbfgu5q3am5oxcfn7wl37'
USER_AGENT = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
              'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36')


def local_name(tag):
    return tag.rsplit('}', 1)[-1].lower() if '}' in tag else tag.lower()


def child_text(node, *names):
    if node is None:
        return ''
    wanted = set(n.lower() for n in names)
    for child in list(node):
        if local_name(child.tag) in wanted and child.text:
            return child.text.strip()
    return ''


def clean_display_name(value):
    """Quita formato Kodi para mostrar; el nombre original se conserva aparte."""
    value = html.unescape(value or '')
    value = re.sub(r'\[/?(?:COLOR(?:\s+|=)?[^\]]*|B|I|U|LIGHT|UPPERCASE|LOWERCASE)\]', '', value, flags=re.I)
    value = re.sub(r'\[/?(?:CR|BR)\]', ' ', value, flags=re.I)
    value = value.replace('magellan>', '').replace('Magellan>', '')
    value = re.sub(r'\s+', ' ', value).strip(' >\t\r\n')
    return value or 'Canal sin nombre'


def decode_magellan_payload(raw):
    """Descodifica el formato usado por getSoup() en Magellan.

    El cuerpo contiene hexadecimal GZIP seguido del marcador y un bloque de
    datos que el lector XML de Magellan no necesita para el catálogo inicial.
    """
    if isinstance(raw, str):
        text = raw.strip().lstrip('\ufeff')
        if MAGELLAN_MARKER in text:
            encoded = text.split(MAGELLAN_MARKER, 1)[0].strip()
            if encoded and re.match(r'^[0-9a-fA-F]+$', encoded) and len(encoded) % 2 == 0:
                try:
                    return gzip.decompress(bytes.fromhex(encoded))
                except Exception as exc:
                    raise ValueError('El bloque GZIP/hex de Magellan no se pudo descomprimir: {0}'.format(exc))
        return text.encode('utf-8')

    data = raw or b''
    try:
        text = data.decode('utf-8-sig')
    except Exception:
        text = None
    if text is not None and MAGELLAN_MARKER in text:
        encoded = text.split(MAGELLAN_MARKER, 1)[0].strip()
        if encoded and re.match(r'^[0-9a-fA-F]+$', encoded) and len(encoded) % 2 == 0:
            try:
                return gzip.decompress(bytes.fromhex(encoded))
            except Exception as exc:
                raise ValueError('El bloque GZIP/hex de Magellan no se pudo descomprimir: {0}'.format(exc))
    if data.startswith(b'\x1f\x8b'):
        try:
            return gzip.decompress(data)
        except Exception:
            pass
    return data


def _decode_text(raw):
    raw = decode_magellan_payload(raw)
    if isinstance(raw, str):
        text = raw
    else:
        try:
            text = raw.decode('utf-8-sig')
        except UnicodeDecodeError:
            try:
                text = raw.decode('cp1252')
            except UnicodeDecodeError:
                text = raw.decode('latin-1', 'replace')
    return text.lstrip('\ufeff').replace('\ufeff', '')


def _clean_xml(raw):
    text = _decode_text(raw)
    # Eliminar caracteres de control y referencias numéricas prohibidos XML 1.0.
    text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', text)
    text = re.sub(r'&#(?:0*[0-8]|0*1[1-9]|0*2[0-9]|0*30|0*31);', '', text, flags=re.I)
    # Escapar ampersands sueltos, sin modificar entidades válidas.
    text = re.sub(r'&(?!#\d+;|#x[0-9a-fA-F]+;|amp;|lt;|gt;|quot;|apos;)', '&amp;', text)
    return text


def _repair_mismatched_tags(text):
    """Reparación limitada de cierres mal balanceados, sin inventar datos."""
    token_pattern = re.compile(r'<!--.*?-->|<!\[CDATA\[.*?\]\]>|<\?.*?\?>|<![^>]*>|</?[^>]+?>', re.S)
    stack = []
    output = []
    cursor = 0
    for match in token_pattern.finditer(text):
        output.append(text[cursor:match.start()])
        token = match.group(0)
        cursor = match.end()
        if token.startswith(('<!--', '<![CDATA[', '<?', '<!')):
            output.append(token)
            continue
        end_match = re.match(r'</\s*([A-Za-z_:][\w:.-]*)\s*>$', token)
        if end_match:
            name = end_match.group(1)
            if name in stack:
                if stack[-1] != name:
                    future = token_pattern.search(text, cursor)
                    future_close = None
                    if future:
                        future_match = re.match(r'</\s*([A-Za-z_:][\w:.-]*)\s*>$', future.group(0))
                        if future_match:
                            future_close = future_match.group(1)
                    if future_close == stack[-1]:
                        continue
                    while stack and stack[-1] != name:
                        output.append('</{0}>'.format(stack.pop()))
                if stack:
                    stack.pop()
                    output.append(token)
            continue
        start_match = re.match(r'<\s*([A-Za-z_:][\w:.-]*)\b', token)
        if start_match:
            output.append(token)
            if not re.search(r'/\s*>$', token):
                stack.append(start_match.group(1))
        else:
            output.append(token)
    output.append(text[cursor:])
    while stack:
        output.append('</{0}>'.format(stack.pop()))
    return ''.join(output)


def parse_xml(raw):
    text = _clean_xml(raw)
    try:
        return ET.fromstring(text)
    except ET.ParseError as first_error:
        repaired = _repair_mismatched_tags(text)
        if repaired != text:
            try:
                warnings.warn('XML mal formado; se aplicó recuperación conservadora: {0}'.format(first_error))
                return ET.fromstring(repaired)
            except ET.ParseError:
                pass
        raise ValueError('El catálogo no contiene XML válido: {0}'.format(first_error))


def _parse_m3u(text):
    """Convierte una M3U a nodos item, conservando grupos y metadatos."""
    root = ET.Element('items')
    current_parent = root
    pending = None
    pending_attrs = {}
    pending_headers = {}
    current_group = ''

    def split_extinf(body):
        quote_char = None
        escaped = False
        for index, char in enumerate(body):
            if escaped:
                escaped = False
                continue
            if char == '\\' and quote_char:
                escaped = True
                continue
            if char in ('"', "'"):
                if quote_char == char:
                    quote_char = None
                elif quote_char is None:
                    quote_char = char
                continue
            if char == ',' and quote_char is None:
                return body[:index], body[index + 1:]
        return body, ''

    def parse_extinf(line):
        body = line[len('#EXTINF:'):]
        meta, label = split_extinf(body)
        attrs = {}
        pattern = r"([\w-]+)\s*=\s*(?:\"([^\"]*)\"|'([^']*)')"
        for match in re.finditer(pattern, meta):
            attrs[match.group(1).lower()] = match.group(2) if match.group(2) is not None else match.group(3)
        return clean_display_name(label), attrs

    def set_group(label):
        nonlocal current_parent, current_group
        clean = clean_display_name(label)
        if not clean or clean.lower().startswith('total listas') or clean == '-':
            return
        if clean == current_group:
            return
        current_group = clean
        current_parent = ET.SubElement(root, 'subchannel')
        ET.SubElement(current_parent, 'name').text = clean

    def flush_header(label):
        clean = clean_display_name(label)
        if re.search(r'\bLISTA\s*\d+\b', clean, re.I):
            set_group(clean)

    def add_header(name, value):
        key = (name or '').strip().lower()
        value = (value or '').strip()
        mapping = {
            'http-user-agent': 'User-Agent', 'user-agent': 'User-Agent',
            'http-referrer': 'Referer', 'http-referer': 'Referer', 'referer': 'Referer',
            'origin': 'Origin', 'http-origin': 'Origin',
            'http-cookie': 'Cookie', 'cookie': 'Cookie',
            'accept': 'Accept', 'authorization': 'Authorization'
        }
        header = mapping.get(key)
        if header and value:
            pending_headers[header] = value

    def append_headers(url):
        if not pending_headers:
            return url
        base, separator, raw_headers = url.partition('|')
        merged = {}
        if separator:
            for pair in raw_headers.split('&'):
                if '=' in pair:
                    name, value = pair.split('=', 1)
                    merged[name.strip().lower()] = (name.strip(), value)
        for name, value in pending_headers.items():
            if name.lower() not in merged:
                merged[name.lower()] = (name, urllib.parse.quote(value, safe='/:;,+-._~'))
        encoded = '&'.join(name + '=' + value for name, value in merged.values())
        return base + '|' + encoded if encoded else url

    for raw_line in text.splitlines():
        line = raw_line.strip().lstrip('\ufeff')
        if not line:
            continue
        if line.upper().startswith('EXTINF:'):
            line = '#' + line
        if line.upper().startswith('#EXTINF:'):
            if pending is not None:
                flush_header(pending)
            pending, pending_attrs = parse_extinf(line)
            continue
        if line.upper().startswith('#EXTVLCOPT:'):
            option = line.split(':', 1)[1]
            if '=' in option:
                name, value = option.split('=', 1)
                add_header(name, value)
            continue
        if line.upper().startswith('#EXTHTTP:'):
            payload = line.split(':', 1)[1]
            try:
                values = json.loads(payload)
                if isinstance(values, dict):
                    for name, value in values.items():
                        add_header(name, str(value))
            except Exception:
                pass
            continue
        if line.upper().startswith('#EXTGRP:'):
            set_group(line.split(':', 1)[1])
            continue
        if line.startswith('#'):
            continue
        if pending is None:
            continue

        group_title = pending_attrs.get('group-title', '').strip()
        if group_title and group_title != '-' and group_title != current_group:
            set_group(group_title)

        item = ET.SubElement(current_parent, 'item')
        # Conservar los atributos M3U originales para identificar logo, país,
        # zona y otros metadatos sin deducir información de la URL.
        for key, value in pending_attrs.items():
            item.set(key, value)
        ET.SubElement(item, 'title').text = pending_attrs.get('tvg-name') or pending
        url = append_headers(line)
        ET.SubElement(item, 'link').text = url
        logo = pending_attrs.get('tvg-logo', '')
        if logo:
            ET.SubElement(item, 'thumbnail').text = logo
        pending = None
        pending_attrs = {}
        pending_headers.clear()
    if pending is not None:
        flush_header(pending)
    return root


def parse_catalog_data(raw):
    text = _decode_text(raw)
    first = text.lstrip()[:200].upper()
    if '#EXTM3U' in first or first.startswith('#EXTINF:'):
        return _parse_m3u(text)
    if '#EXTINF:' in text[:1000]:
        return _parse_m3u(text)
    return parse_xml(text)


def fetch_catalog(url=CATALOG_URL, timeout=25):
    """Descarga un recurso, conservando headers indicados en URL|Header=Value."""
    request_url = url
    headers = {'User-Agent': USER_AGENT}
    if '|' in url:
        request_url, raw_headers = url.split('|', 1)
        for pair in raw_headers.split('&'):
            if '=' in pair:
                name, value = pair.split('=', 1)
                headers[name.strip()] = urllib.parse.unquote(value.strip())
    request = urllib.request.Request(request_url, headers=headers)
    with urllib.request.urlopen(request, timeout=timeout) as response:
        raw = response.read()
        encoding = response.headers.get('Content-Encoding', '').lower()
    if encoding == 'gzip' and not raw.startswith(b'\x1f\x8b'):
        try:
            raw = gzip.decompress(raw)
        except Exception:
            pass
    root = parse_catalog_data(raw)
    return root, raw


def _region_nodes(root):
    if local_name(root.tag) == 'channels':
        nodes = [n for n in list(root) if local_name(n.tag) == 'channel']
    else:
        nodes = [n for n in root.iter() if local_name(n.tag) == 'channel']
    return [n for n in nodes if child_text(n, 'name')]


def list_regions(root):
    result = []
    for index, node in enumerate(_region_nodes(root)):
        name = child_text(node, 'name')
        if name:
            result.append({'name': name, 'label': clean_display_name(name), 'index': index})
    return result


_PARENTHETICAL_GEO = {
    'mex': 'Mex', 'mexico': 'Mexico', 'mx': 'MX',
    'col': 'Col', 'co': 'CO', 'arg': 'Arg', 'ar': 'AR',
    'c rica': 'C.Rica', 'costa rica': 'Costa Rica', 'cr': 'CR',
    'r dominic': 'R.Dominic.', 'republica dominicana': 'R.Dominic.', 'do': 'DO',
    'ven': 'Ven', 've': 'VE', 'ecu': 'Ecu', 'ec': 'EC',
    'chi': 'Chi', 'cl': 'CL', 'usa': 'USA', 'us': 'US',
    'bol': 'Bol', 'bo': 'BO', 'hond': 'Hond.', 'hn': 'HN',
    'pe': 'Pe', 'peru': 'Peru', 'pr': 'PR', 'puerto rico': 'Puerto Rico',
}
_SUFFIX_GEO = {
    'colombia': 'Colombia', 'argentina': 'Argentina', 'mexico': 'Mexico',
    'peru': 'Peru', 'venezuela': 'Venezuela', 'ecuador': 'Ecuador',
    'chile': 'Chile', 'bolivia': 'Bolivia', 'brasil': 'Brasil',
    'brazil': 'Brasil', 'uruguay': 'Uruguay', 'paraguay': 'Paraguay',
    'costa rica': 'Costa Rica', 'honduras': 'Honduras', 'guatemala': 'Guatemala',
    'panama': 'Panama', 'nicaragua': 'Nicaragua', 'el salvador': 'El Salvador',
    'puerto rico': 'Puerto Rico', 'united states': 'USA', 'usa': 'USA',
    'norte': 'Norte', 'sur': 'Sur', 'internacional': 'Internacional',
    'latam': 'Latam', 'latinoamerica': 'Latinoamerica',
}


def _fold_geo(value):
    value = unicodedata.normalize('NFKD', value or '')
    value = ''.join(char for char in value if not unicodedata.combining(char))
    value = value.casefold()
    return re.sub(r'[^a-z0-9]+', ' ', value).strip()


def _node_zone(node):
    # Solo se confía en atributos/campos que declaran explícitamente una zona.
    zone_names = ('zone', 'region', 'area', 'country', 'location', 'locale',
                  'tvg-country', 'country-code', 'tvg_region')
    for key, value in getattr(node, 'attrib', {}).items():
        if local_name(key) in zone_names and value.strip():
            return value.strip()
    return child_text(node, 'zone', 'region', 'area', 'country', 'location', 'locale')


def _explicit_title_zone(title):
    """Reconoce zonas explícitas, no códigos de distribución o calidad."""
    clean = clean_display_name(title or '')
    without_code = clean
    match = re.search(r'\(([^()]*)\)\s*$', clean)
    if match:
        token = match.group(1).strip()
        normalized = _fold_geo(token)
        if normalized in _PARENTHETICAL_GEO:
            return _PARENTHETICAL_GEO[normalized]
        if normalized in _SUFFIX_GEO:
            return _SUFFIX_GEO[normalized]
        # Códigos como (CC26), (ESPN07), (T6) o (Digicast) no son regiones.
        without_code = clean[:match.start()].strip()

    folded = _fold_geo(without_code)
    # Se toleran sufijos de definición de imagen después del país/zona.
    folded = re.sub(r'\s+(?:hd|sd|fhd|uhd|4k|8k)$', '', folded)
    for phrase in sorted(_SUFFIX_GEO, key=len, reverse=True):
        if folded == phrase or folded.endswith(' ' + phrase):
            return _SUFFIX_GEO[phrase]
    return ''



def decode_external_link(value):
    """Magellan puede guardar externallink en Base32 invertido."""
    value = (value or '').strip()
    if not value:
        return ''
    try:
        candidate = base64.b32decode(value[::-1].upper()).decode('utf-8').strip()
        if candidate.startswith(('http://', 'https://', 'plugin://', 'smb://', 'nfs://')):
            return candidate
    except Exception:
        pass
    return value

def _is_usable_link(value):
    value = (value or '').strip()
    if not value or value.lower() in ('ignorme', 'h', 'none', 'null'):
        return False
    candidate = value.split('|', 1)[0].strip()
    parsed = urllib.parse.urlsplit(candidate)
    if parsed.scheme.lower() in ('http', 'https'):
        host = (parsed.hostname or '').lower()
        # Magellan utiliza "http://185" como marcador/aviso, no como stream.
        if not host or host in ('185', 'h', 'null', 'none'):
            return False
        if '.' not in host and not host.isdigit() and host != 'localhost':
            return False
        if host.isdigit() and '.' not in host:
            return False
        return True
    return parsed.scheme.lower() in ('plugin', 'rtmp', 'rtsp', 'udp', 'acestream',
                                      'smb', 'nfs', 'file', 'magnet')


def _sources(item):
    sources = []
    regexes = []
    for child in list(item):
        if local_name(child.tag) == 'regex':
            definition = {}
            for field in list(child):
                if field.text is not None:
                    definition[local_name(field.tag)] = field.text.strip()
            if definition.get('name'):
                regexes.append(definition)

    def add(url, kind, node):
        if not _is_usable_link(url):
            return
        sources.append({'url': url.strip(), 'kind': kind,
                        'regexes': regexes, 'zone': _node_zone(node)})

    for child in list(item):
        tag = local_name(child.tag)
        value = (child.text or '').strip()
        if not value:
            continue
        if tag == 'link':
            add(value, 'direct', child)
        elif tag == 'inputstream':
            add(value, 'inputstream', child)
        elif tag == 'urlsolve':
            add(value, 'urlsolve', child)
        elif tag == 'slproxy':
            add(value, 'slproxy', child)
        elif tag == 'f4m':
            if value.startswith('plugin://'):
                url = value
            else:
                stream_type = 'HLS' if '.m3u8' in value.lower() else ('TSDOWNLOADER' if '.ts' in value.lower() else 'SIMPLE')
                url = 'plugin://plugin.video.f4mTester/?url={0}&streamtype={1}'.format(
                    urllib.parse.quote_plus(value), stream_type)
            add(url, 'plugin', child)
        elif tag == 'yt-dl':
            add(value, 'youtube-dl', child)
        elif tag in ('dm', 'dmlive', 'utube', 'sportsdevil'):
            add(value, tag, child)
    return sources


def _node_thumbnail(item):
    return child_text(item, 'thumbnail', 'logo', 'icon')


def _node_title(item):
    return child_text(item, 'title', 'name') or 'Canal sin nombre'


def _is_movie_container(label):
    """Detecta carpetas de películas para que no entren en la lista de TV."""
    value = _fold_geo(clean_display_name(label or ''))
    return bool(re.search(r'(^|\b)(peliculas?|movies?|filmes?|cine)(\b|$)', value))


def _is_folder(item):
    """Un externallink con link vacío/ignorme describe una carpeta, no canal."""
    external = child_text(item, 'externallink')
    sources = _sources(item)
    raw_link = child_text(item, 'link').strip().lower()
    if external and not sources and raw_link in ('', 'ignorme', 'h', 'none', 'null'):
        return True
    # Items sin enlace directo pero con página externa se consideran carpetas.
    if external and not sources:
        return True
    return False


def _iter_catalog_nodes(root):
    """Itera los elementos en orden documental, conservando categorías."""
    for child in list(root):
        tag = local_name(child.tag)
        if tag in ('item', 'subitem', 'channel'):
            yield child, None
        elif tag in ('subchannel', 'category', 'group', 'folder'):
            yield child, 'group'
        else:
            # Contenedores neutros como <items> anidado no se convierten
            # en categorías nuevas; se recorren conservando el orden.
            for nested, kind in _iter_catalog_nodes(child):
                yield nested, kind


def _make_entry(item, region_name, path, region_fanart, duplicates):
    raw_title = _node_title(item)
    title = clean_display_name(raw_title)
    explicit_node_zone = _node_zone(item)
    legacy_title_zone = ''
    legacy_match = re.search(r'\(([^()]{2,32})\)\s*$', title or '')
    if legacy_match:
        legacy_title_zone = legacy_match.group(1).strip()
    item_zone = explicit_node_zone or _explicit_title_zone(title)
    legacy_item_zone = explicit_node_zone or legacy_title_zone
    all_sources = _sources(item)
    groups = {}
    for source in all_sources:
        source_zone = source.get('zone') or item_zone
        groups.setdefault(source_zone, []).append(source)
    if len(groups) > 1:
        variants = list(groups.items())
    else:
        variants = [(item_zone or (list(groups.keys())[0] if groups else ''), all_sources)]

    entries = []
    for zone, sources in variants:
        legacy_zone = next((src.get('zone') for src in sources if src.get('zone')), legacy_item_zone)
        key = (tuple(path), raw_title, legacy_zone)
        duplicates[key] = duplicates.get(key, 0) + 1
        ordinal = duplicates[key]
        # Mantener el mismo identificador de la versión 1.0.0 para que las
        # selecciones existentes sobrevivan a la corrección de zonas.
        identity = '\x1f'.join((region_name, '/'.join(path), raw_title, legacy_zone, str(ordinal)))
        channel_id = hashlib.sha1(identity.encode('utf-8')).hexdigest()
        entries.append({
            'id': channel_id,
            'region': region_name,
            'path': list(path),
            'name': title,
            'original_name': raw_title,
            'zone': zone,
            'thumbnail': _node_thumbnail(item),
            'fanart': child_text(item, 'fanart') or region_fanart,
            'info': child_text(item, 'info', 'description'),
            'genre': child_text(item, 'genre'),
            'sources': sources,
        })
    return entries


def _collect_entries(root, region_name, path=None, fetcher=None, seen=None,
                     depth=0, max_depth=8, region_fanart=''):
    path = list(path or [])
    seen = set(seen or [])
    if depth > max_depth:
        return []
    duplicates = {}
    results = []
    if not region_fanart:
        region_fanart = child_text(root, 'fanart')

    for node, kind in _iter_catalog_nodes(root):
        if kind == 'group':
            label = clean_display_name(child_text(node, 'name', 'title'))
            if _is_movie_container(label):
                continue
            results.extend(_collect_entries(node, region_name,
                path + ([label] if label else []), fetcher, seen, depth + 1,
                max_depth, child_text(node, 'fanart') or region_fanart))
            continue

        title = _node_title(node)
        # La lista de películas puede aparecer como carpeta externallink dentro
        # de la región. Se excluye de la selección de canales de televisión.
        if _is_movie_container(title):
            continue
        external = decode_external_link(child_text(node, 'externallink'))
        if _is_folder(node) and external:
            if fetcher and external not in seen and depth < max_depth:
                try:
                    child_root, _raw = fetcher(external)
                    child_path = path + [clean_display_name(title)]
                    results.extend(_collect_entries(child_root, region_name,
                        child_path, fetcher, seen | set([external]), depth + 1,
                        max_depth, child_text(node, 'fanart') or region_fanart))
                except Exception as exc:
                    warnings.warn('No se pudo abrir la lista externa {0}: {1}'.format(external, exc))
            continue

        raw_link = child_text(node, 'link')
        if raw_link and not _sources(node) and not _is_usable_link(raw_link):
            continue
        entries = _make_entry(node, region_name, path, region_fanart, duplicates)
        results.extend(entries)
    return results


def _merge_zone(entry):
    """Zona explícita del canal; también reconoce carpetas geográficas."""
    zone = (entry.get('zone') or '').strip()
    if zone:
        return zone
    for part in reversed(entry.get('path') or []):
        detected = _explicit_title_zone(part)
        if detected:
            return detected
    return ''


def _merge_title_key(entry, zone):
    """Nombre estable para reunir variantes técnicas del mismo canal.

    Elimina calidad/resolución y códigos internos de distribución, pero
    conserva números del canal y calificadores geográficos reconocidos.
    """
    title = clean_display_name(entry.get('original_name') or entry.get('name') or '')

    # Algunas listas de Magellan anteponen un número de orden al nombre:
    # '1.Tnt Sports', '2.Tnt Sports', etc. Ese ordinal identifica la fila o
    # variante de la lista, NO el canal. Se elimina solo al calcular la clave
    # de agrupación; los números propios del canal (ESPN 1, ESPN 2) quedan.
    title = re.sub(r'^\s*\d{1,3}\s*[.)]\s*', '', title)

    # Los códigos entre paréntesis (por ejemplo Digicast o ESPN07) no son
    # canales distintos. Los nombres geográficos reconocidos sí se conservan.
    def keep_geo_parenthetical(match):
        token = match.group(1).strip()
        folded_token = _fold_geo(token)
        return match.group(0) if (folded_token in _PARENTHETICAL_GEO or
                                  folded_token in _SUFFIX_GEO) else ''
    title = re.sub(r'\s*\(([^()]*)\)\s*$', keep_geo_parenthetical, title)

    # Quita la calidad/resolución tanto separada como pegada al número
    # (ESPN 5HD), además de los formatos escritos entre corchetes.
    title = re.sub(r'\s*[\[(](?:HD|FHD|UHD|4K|8K|SD|1080[pi]?|720[pi]?|576[pi]?|480[pi]?)(?:\s*|\s*[/|,-]\s*)[\])]', '', title, flags=re.I)
    title = re.sub(r'(?:\s*[-|•/]\s*|\s+)(?:HD|FHD|UHD|4K|8K|SD|1080[pi]?|720[pi]?|576[pi]?|480[pi]?|60\s*FPS|50\s*FPS)\s*$', '', title, flags=re.I)
    title = re.sub(r'(?:HD|FHD|UHD|4K|8K|SD|1080[pi]?|720[pi]?|576[pi]?|480[pi]?|60FPS|50FPS)$', '', title, flags=re.I)

    # Si la zona está identificada, elimina su repetición del título; la zona
    # se mantiene como parte independiente de la clave de agrupación.
    if zone:
        title = re.sub(r'\s*[\[(]?\s*' + re.escape(zone) + r'\s*[\])]?$','', title, flags=re.I).strip()

    # Algunas fuentes colocan la zona después de la calidad (p. ej.
    # 'ESPN 1 HD Norte'); al quitar la zona puede quedar HD al final.
    title = re.sub(r'(?:\s*[-|•/]\s*|\s+)?(?:HD|FHD|UHD|4K|8K|SD|1080[pi]?|720[pi]?|576[pi]?|480[pi]?|60\s*FPS|50\s*FPS)$', '', title, flags=re.I).strip()

    normalized = _fold_geo(title)
    # Magellan mezcla formatos como ESPN1 y ESPN 1; la cifra sigue formando
    # parte de la identidad, por lo que ESPN 1 no se mezcla con ESPN 2.
    normalized = re.sub(r'(?<=[a-z])(?=\d)|(?<=\d)(?=[a-z])', ' ', normalized)
    return re.sub(r'\s+', ' ', normalized).strip()


def _merge_exact_duplicate_channels(entries):
    """Reúne transmisiones del mismo canal y preserva sus identificadores viejos.

    Se agrupa por región, nombre normalizado y zona. La carpeta/lista de origen
    no crea un canal nuevo; sí se conserva como metadato. Variantes geográficas
    (Norte/Sur, países, etc.) permanecen separadas.
    """
    merged = []
    index = {}
    for entry in entries:
        zone = _merge_zone(entry)
        if zone:
            entry['zone'] = zone
        title_key = _merge_title_key(entry, zone)
        # Solo los nombres realmente vacíos/genéricos se mantienen separados
        # por carpeta. No tratar "Canal 13" o "TV Peru" como genéricos:
        # son nombres identificables y sus transmisiones de distintas listas
        # deben reunirse. Para decidirlo usamos el título ANTES de quitar la
        # zona; así "TV Peru" no se convierte erróneamente en solo "TV".
        generic_title = _merge_title_key(entry, '')
        generic = bool(re.fullmatch(r'(?:canal|channel|tv|live|stream)', generic_title))
        key = (entry.get('region'), title_key, _fold_geo(zone),
               tuple(entry.get('path') or []) if generic else ())
        existing_index = index.get(key)
        if existing_index is None:
            entry['aliases'] = [entry.get('id')] if entry.get('id') else []
            entry['alternate_paths'] = [list(entry.get('path') or [])]
            index[key] = len(merged)
            merged.append(entry)
            continue

        current = merged[existing_index]
        # Conservar todos los IDs antiguos como alias del canal combinado;
        # así las selecciones guardadas antes de actualizar siguen funcionando.
        aliases = current.setdefault('aliases', [current.get('id')])
        for identity in [entry.get('id')] + list(entry.get('aliases') or []):
            if identity and identity not in aliases:
                aliases.append(identity)
        paths = current.setdefault('alternate_paths', [list(current.get('path') or [])])
        incoming_path = list(entry.get('path') or [])
        if incoming_path not in paths:
            paths.append(incoming_path)
        # Unir las fuentes y quitar duplicados exactos sin cambiar su orden.
        known = set((src.get('kind'), src.get('url')) for src in current.get('sources', []))
        for source in entry.get('sources', []):
            marker = (source.get('kind'), source.get('url'))
            if marker not in known:
                current.setdefault('sources', []).append(source)
                known.add(marker)
        for field in ('thumbnail', 'fanart', 'info', 'genre'):
            if not current.get(field) and entry.get(field):
                current[field] = entry[field]
    return merged


def extract_region_channels(root, region_name, fetcher=None):
    """Resuelve la categoría original y aplana solo sus sublistas reales."""
    region_node = None
    for node in _region_nodes(root):
        if child_text(node, 'name') == region_name:
            region_node = node
            break
    if region_node is None:
        return []

    region_fanart = child_text(region_node, 'fanart')
    has_inline_items = any(local_name(n.tag) in ('item', 'subitem')
                           for n in region_node.iter() if n is not region_node)
    external = child_text(region_node, 'externallink')
    if not has_inline_items and external and fetcher:
        try:
            child_root, _raw = fetcher(external)
            entries = _collect_entries(child_root, region_name, [], fetcher,
                                       set([external]), 0, 8, region_fanart)
            return _merge_exact_duplicate_channels(entries)
        except Exception as exc:
            warnings.warn('No se pudo cargar la región {0}: {1}'.format(region_name, exc))
            return []
    entries = _collect_entries(region_node, region_name, [], fetcher,
                               set(), 0, 8, region_fanart)
    return _merge_exact_duplicate_channels(entries)


def extract_all_sources(root, max_depth=4, seen=None, fetcher=None):
    """Extrae fuentes directas sin combinar canales; útil para diagnósticos."""
    seen = set(seen or [])
    found = []
    for node in root.iter():
        if local_name(node.tag) not in ('item', 'subitem', 'channel'):
            continue
        if _is_folder(node):
            continue
        found.extend(_sources(node))
    unique = []
    fingerprints = set()
    for source in found:
        marker = (source.get('kind'), source.get('url'))
        if marker not in fingerprints:
            fingerprints.add(marker)
            unique.append(source)
    return unique
