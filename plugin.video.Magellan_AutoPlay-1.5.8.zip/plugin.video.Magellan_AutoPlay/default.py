# -*- coding: utf-8 -*-
"""Magellan AutoPlay - Kodi plugin entry point."""
from __future__ import absolute_import, unicode_literals

import json
import os
import sys
import traceback
import hashlib
import re
import shutil
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = 'plugin.video.Magellan_AutoPlay'
ADDON_NAME = 'Magellan AutoPlay'
BASE_URL = sys.argv[0]
HANDLE = int(sys.argv[1])
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
if not xbmcvfs.exists(PROFILE):
    xbmcvfs.mkdirs(PROFILE)
CACHE_FILE = os.path.join(PROFILE, 'catalog.xml')
CONFIG_FILE = os.path.join(PROFILE, 'settings.json')
HEALTH_FILE = os.path.join(PROFILE, 'source_health.json')
GROUPS_FILE = os.path.join(PROFILE, 'grupos_manuales.json')
ORGANIZER_FILE = os.path.join(PROFILE, 'organizacion_manual.json')
ORGANIZER_BACKUP_FILE = os.path.join(PROFILE, 'organizacion_manual.backup.json')
SOURCE_CACHE_DIR = os.path.join(PROFILE, 'source_cache')
ADDON_PATH = ADDON.getAddonInfo('path')
SEED_DIR = os.path.join(ADDON_PATH, 'resources', 'catalog_seeds')

# Copias aportadas para las mismas referencias externallink del árbol original.
# Se usan como respaldo sin crear regiones ni canales fuera del catálogo.
SEED_URLS = {
    'https://pastebin.com/raw/5jZTyKZP': 'espanhalatinos.txt',
    'https://pastebin.com/raw/7kQZWCGu': 'canaleslatinos.txt',
    'https://pastebin.com/raw/9X2F1NX8': 'canaleslatinosvariaslistas.txt',
}

LIB = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'lib')
if LIB not in sys.path:
    sys.path.insert(0, LIB)

from catalog import (CATALOG_URL, clean_display_name, extract_all_sources,
                     extract_region_channels, fetch_catalog, list_regions,
                     parse_catalog_data, set_manual_groups)
import health
from playback import play_sources, play_channel_sequence

health.init(HEALTH_FILE)

GROUPS_TEMPLATE = '{\n}\n'

DEFAULT_CONFIG = {
    'setup_complete': False,
    'region': '',
    'selected': [],
    'snapshots': {},
}


def log(message, level=xbmc.LOGINFO):
    xbmc.log('[{0}] {1}'.format(ADDON_NAME, message), level)


def notify(message, time_ms=4000):
    if ADDON.getSetting('show_notifications') != 'false':
        xbmcgui.Dialog().notification(ADDON_NAME, message, ADDON.getAddonInfo('icon'), time=time_ms)


def load_config():
    config = dict(DEFAULT_CONFIG)
    try:
        with open(CONFIG_FILE, 'r', encoding='utf-8') as stream:
            stored = json.load(stream)
        if isinstance(stored, dict):
            config.update(stored)
    except Exception:
        pass
    if not isinstance(config.get('selected'), list):
        config['selected'] = []
    if not isinstance(config.get('snapshots'), dict):
        config['snapshots'] = {}
    return config


def save_config(config):
    temp_file = CONFIG_FILE + '.tmp'
    with open(temp_file, 'w', encoding='utf-8') as stream:
        json.dump(config, stream, ensure_ascii=False, indent=2, sort_keys=True)
    try:
        os.replace(temp_file, CONFIG_FILE)
    except Exception:
        if os.path.exists(CONFIG_FILE):
            os.remove(CONFIG_FILE)
        os.rename(temp_file, CONFIG_FILE)


def _ensure_dir(path):
    if not os.path.isdir(path):
        os.makedirs(path)


def _source_cache_path(url):
    digest = hashlib.sha1(url.encode('utf-8')).hexdigest()
    _ensure_dir(SOURCE_CACHE_DIR)
    return os.path.join(SOURCE_CACHE_DIR, digest + '.dat')


def _read_catalog_file(path):
    with open(path, 'rb') as stream:
        raw = stream.read()
    return parse_catalog_data(raw), raw


def _seed_path(url):
    filename = SEED_URLS.get(url)
    if not filename:
        return ''
    candidate = os.path.join(SEED_DIR, filename)
    return candidate if os.path.isfile(candidate) else ''


def load_external_catalog(url, force=False):
    """Carga sublistas de Magellan con caché y respaldo en archivos aportados."""
    cache_path = _source_cache_path(url)
    if not force and os.path.isfile(cache_path):
        try:
            return _read_catalog_file(cache_path)
        except Exception as exc:
            log('Caché externa inválida ({0}): {1}'.format(url, exc), xbmc.LOGWARNING)

    try:
        root, raw = fetch_catalog(url)
        temp_file = cache_path + '.tmp'
        with open(temp_file, 'wb') as stream:
            stream.write(raw)
        try:
            os.replace(temp_file, cache_path)
        except Exception:
            if os.path.exists(cache_path):
                os.remove(cache_path)
            os.rename(temp_file, cache_path)
        return root, raw
    except Exception as exc:
        log('No se pudo descargar lista externa {0}: {1}'.format(url, exc), xbmc.LOGWARNING)

    if os.path.isfile(cache_path):
        try:
            return _read_catalog_file(cache_path)
        except Exception:
            pass

    seed = _seed_path(url)
    if seed:
        root, raw = _read_catalog_file(seed)
        try:
            with open(cache_path, 'wb') as stream:
                stream.write(raw)
        except Exception:
            pass
        log('Se utilizó copia local de respaldo para {0}'.format(url))
        return root, raw
    raise IOError('La lista externa no está disponible y no hay copia local: {0}'.format(url))


def load_catalog(force=False):
    """Lee el catálogo principal, descodificando el envoltorio GZIP/hex Magellan."""
    if force:
        try:
            root, raw = fetch_catalog(CATALOG_URL)
            temp_file = CACHE_FILE + '.tmp'
            with open(temp_file, 'wb') as stream:
                stream.write(raw)
            try:
                os.replace(temp_file, CACHE_FILE)
            except Exception:
                if os.path.exists(CACHE_FILE):
                    os.remove(CACHE_FILE)
                os.rename(temp_file, CACHE_FILE)
            return root, 'remote'
        except Exception as exc:
            log('No se pudo actualizar el catálogo principal: {0}'.format(exc), xbmc.LOGWARNING)
            if os.path.isfile(CACHE_FILE):
                try:
                    return _read_catalog_file(CACHE_FILE)[0], 'cache'
                except Exception:
                    pass
            seed = os.path.join(SEED_DIR, 'magellan.txt')
            if os.path.isfile(seed):
                return _read_catalog_file(seed)[0], 'seed'
            raise

    if os.path.isfile(CACHE_FILE):
        try:
            return _read_catalog_file(CACHE_FILE)[0], 'cache'
        except Exception as exc:
            log('La caché principal no es válida: {0}'.format(exc), xbmc.LOGWARNING)

    try:
        root, raw = fetch_catalog(CATALOG_URL)
        with open(CACHE_FILE, 'wb') as stream:
            stream.write(raw)
        return root, 'remote'
    except Exception as exc:
        log('No se pudo descargar el catálogo principal: {0}'.format(exc), xbmc.LOGWARNING)
        seed = os.path.join(SEED_DIR, 'magellan.txt')
        if os.path.isfile(seed):
            root, raw = _read_catalog_file(seed)
            with open(CACHE_FILE, 'wb') as stream:
                stream.write(raw)
            return root, 'seed'
        raise


def load_manual_groups():
    """Lee grupos_manuales.json (opcional) con nombres que son la misma señal."""
    groups = {}
    if os.path.isfile(GROUPS_FILE):
        try:
            with open(GROUPS_FILE, 'r', encoding='utf-8') as stream:
                loaded = json.load(stream)
            if isinstance(loaded, dict):
                groups = loaded
        except Exception as exc:
            log('grupos_manuales.json no es válido y se ignora: {0}'.format(exc), xbmc.LOGWARNING)
    set_manual_groups(groups)



def _source_uid(source):
    """Identificador estable de una fuente; nunca guarda la URL en el archivo de organización."""
    raw = (source.get('kind', '') + '\n' + source.get('url', '')).encode('utf-8')
    return hashlib.sha1(raw).hexdigest()


def _read_organizer():
    try:
        with open(ORGANIZER_FILE, 'r', encoding='utf-8') as stream:
            data = json.load(stream)
        if isinstance(data, dict) and isinstance(data.get('regions'), dict):
            return data
    except Exception:
        pass
    return {'version': 1, 'regions': {}}


def _write_organizer(data):
    # Copia de seguridad de la última organización válida para poder deshacer.
    if os.path.isfile(ORGANIZER_FILE):
        try:
            shutil.copy2(ORGANIZER_FILE, ORGANIZER_BACKUP_FILE)
        except Exception as exc:
            log('No se pudo crear copia de seguridad del organizador: {0}'.format(exc), xbmc.LOGWARNING)
    temp = ORGANIZER_FILE + '.tmp'
    with open(temp, 'w', encoding='utf-8') as stream:
        json.dump(data, stream, ensure_ascii=False, indent=2)
    os.replace(temp, ORGANIZER_FILE)


def _entry_copy(entry):
    return json.loads(json.dumps(entry, ensure_ascii=False))


def _apply_manual_organization(entries, region_name):
    """Reconstruye canales desde las fuentes individuales guardadas por el usuario."""
    data = _read_organizer()
    region_data = data.get('regions', {}).get(region_name)
    if not isinstance(region_data, dict) or not isinstance(region_data.get('channels'), list):
        return entries

    source_map = {}
    owner_map = {}
    for entry in entries:
        for source in _expand_sources(entry):
            uid = _source_uid(source)
            source_map.setdefault(uid, source)
            owner_map.setdefault(uid, entry)

    result, consumed = [], set()
    for record in region_data.get('channels', []):
        if not isinstance(record, dict):
            continue
        sources = [source_map[uid] for uid in record.get('sources', [])
                   if uid in source_map and uid not in consumed]
        if not sources:
            continue
        consumed.update(_source_uid(source) for source in sources)
        owners = [owner_map.get(_source_uid(source)) for source in sources]
        owners = [owner for owner in owners if owner]
        original = owners[0] if owners else {}
        item = _entry_copy(original)
        item['id'] = record.get('id') or ('manual-' + hashlib.sha1(
            (region_name + '|' + record.get('name', '')).encode('utf-8')).hexdigest()[:16])
        item['name'] = record.get('name') or original.get('name', 'Canal')
        item['original_name'] = item['name']
        item['sources'] = sources
        aliases = set(original.get('aliases') or [])
        aliases.update(owner.get('id', '') for owner in owners)
        for owner in owners:
            aliases.update(owner.get('aliases') or [])
        aliases.discard('')
        item['aliases'] = list(aliases)
        item['thumbnail'] = record.get('thumbnail') or original.get('thumbnail', '')
        item['_manual_channel'] = True
        result.append(item)

    # Las fuentes nuevas que llegaron con una actualización permanecen en su canal
    # original; nunca se incorporan solas a un grupo manual ya existente.
    for entry in entries:
        remaining = [source for source in _expand_sources(entry)
                     if _source_uid(source) not in consumed]
        if remaining:
            item = _entry_copy(entry)
            item['sources'] = remaining
            result.append(item)
    return result


def get_region_channels(root, region_name):
    load_manual_groups()
    entries = extract_region_channels(root, region_name, fetcher=load_external_catalog)
    return _apply_manual_organization(entries, region_name)


def plugin_url(action, **kwargs):
    params = {'action': action}
    params.update(kwargs)
    return BASE_URL + '?' + urllib.parse.urlencode(params)


def add_directory(label, action, icon='', fanart='', description='', context=None):
    item = xbmcgui.ListItem(label=label)
    art = {}
    if icon:
        art['thumb'] = icon
        art['icon'] = icon
    if fanart:
        art['fanart'] = fanart
    if art:
        item.setArt(art)
    if description:
        item.setInfo('video', {'title': label, 'plot': description})
    if context:
        item.addContextMenuItems(context)
    xbmcplugin.addDirectoryItem(HANDLE, action, item, True)


def _display_channel_name(value):
    label = clean_display_name(value or 'Canal sin nombre')
    # Quita ordinales de fila de las listas (1.Tnt Sports), no números
    # integrados en el nombre real del canal (ESPN 1, Canal 13).
    label = re.sub(r'^\s*\d{1,3}\s*[.)]\s*', '', label)
    # Quita únicamente etiquetas técnicas habituales; conserva números y
    # calificadores geográficos como Norte, Sur, Este y Oeste.
    label = re.sub(r'\s*[-|•/]\s*(?:HD|FHD|UHD|4K|8K|SD|1080[pi]?|720[pi]?|576[pi]?|480[pi]?)(?:\s*[-|•/]?.*)?$', '', label, flags=re.I)
    label = re.sub(r'\s*\b(?:4K|8K|FHD|UHD|HD|SD|1080[pi]?|720[pi]?|576[pi]?|480[pi])\b', '', label, flags=re.I)
    label = re.sub(r'\s*\[[^]]*(?:HD|FHD|UHD|4K|1080[pi]?|720[pi]?)[^]]*\]\s*$', '', label, flags=re.I)
    return re.sub(r'\s+', ' ', label).strip(' -|•') or clean_display_name(value)


def _channel_label(entry):
    label = _display_channel_name(entry.get('name') or 'Canal sin nombre')
    zone = entry.get('zone')
    if zone and zone.casefold() not in label.casefold():
        label += ' — ' + zone
    # No mostrar la carpeta/lista de procedencia en el nombre: puede ser muy
    # extensa y no forma parte del nombre del canal. Las zonas se mantienen
    # arriba como calificadores explícitos (Norte, Sur, país, etc.).
    return label


def _confirm_selection(region_name, entries):
    labels = [_channel_label(entry) for entry in entries]
    preview = labels[:12]
    if len(labels) > 12:
        preview.append('… y {0} canales más'.format(len(labels) - 12))
    if not preview:
        preview = ['No se seleccionaron canales.']
    return xbmcgui.Dialog().yesno(
        ADDON_NAME,
        'Región: {0}'.format(clean_display_name(region_name)),
        'Canales seleccionados: {0}'.format(len(entries)),
        '\n'.join(preview),
    )


def _store_snapshots(config, entries):
    for entry in entries:
        config['snapshots'][entry['id']] = {
            'name': entry.get('name', 'Canal'),
            'original_name': entry.get('original_name', entry.get('name', 'Canal')),
            'region': entry.get('region', ''),
            'path': entry.get('path', []),
            'zone': entry.get('zone', ''),
            'thumbnail': entry.get('thumbnail', ''),
            'fanart': entry.get('fanart', ''),
        }


def _select_region(root, heading='Selecciona una región de Magellan'):
    regions = list_regions(root)
    # Este build trabaja con el catálogo latino aportado. Se conserva el
    # nombre original de Magellan y no se inventan ni renombran regiones.
    latino_regions = [r for r in regions if 'LATINOS' in (r.get('label') or clean_display_name(r.get('name', ''))).upper()]
    if latino_regions:
        regions = latino_regions
    if not regions:
        xbmcgui.Dialog().ok(ADDON_NAME, 'El catálogo no contiene regiones reconocibles.')
        return None
    index = xbmcgui.Dialog().select(heading, [r.get('label') or clean_display_name(r['name']) for r in regions])
    if index < 0:
        return None
    return regions[index]['name']


def _select_channel_ids(entries, heading, preselected=None):
    entries = [entry for entry in entries if not _is_fast_service(entry)]
    if not entries:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Esta región no contiene canales seleccionables.')
        return None
    preselected = set(preselected or [])
    options = ['Seleccionar todos', 'Deseleccionar todos', 'Elegir individualmente', 'Cancelar']
    choice = xbmcgui.Dialog().select(heading, options)
    if choice == 0:
        return [entry['id'] for entry in entries]
    if choice == 1:
        return []
    if choice != 2:
        return None

    labels = [_channel_label(entry) for entry in entries]
    preselect_indices = [i for i, entry in enumerate(entries) if entry['id'] in preselected]
    try:
        result = xbmcgui.Dialog().multiselect(heading, labels, preselect=preselect_indices)
    except TypeError:
        # Compatibilidad con implementaciones de Kodi que no aceptan preselect.
        result = xbmcgui.Dialog().multiselect(heading, labels)
    if result is None:
        return None
    return [entries[i]['id'] for i in result if 0 <= i < len(entries)]


def run_wizard(root, config=None):
    config = config or load_config()
    region_name = _select_region(root)
    if not region_name:
        return False
    entries = get_region_channels(root, region_name)
    selected_ids = _select_channel_ids(entries, 'Selecciona los canales que quieres ver')
    if selected_ids is None:
        return False
    selected_set = set(selected_ids)
    selected_entries = [entry for entry in entries if entry['id'] in selected_set]
    if not _confirm_selection(region_name, selected_entries):
        return False
    config['region'] = region_name
    config['selected'] = [entry['id'] for entry in selected_entries]
    config['setup_complete'] = True
    _store_snapshots(config, selected_entries)
    save_config(config)
    notify('Configuración guardada: {0} canales'.format(len(selected_entries)))
    return True


def _catalog_entry_map(root, config):
    # Los IDs antiguos de variantes ahora apuntan al canal consolidado.
    entries = get_region_channels(root, config.get('region', '')) if config.get('region') else []
    result = {}
    for entry in entries:
        result[entry['id']] = entry
        for alias in entry.get('aliases', []):
            result[alias] = entry

    # Migra selecciones duplicadas de versiones anteriores y limpia las
    # fuentes FAST ya excluidas, sin alterar el resto de canales guardados.
    original_snapshots = dict(config.get('snapshots', {}))
    canonical = []
    seen = set()
    for channel_id in config.get('selected', []):
        entry = result.get(channel_id)
        if entry and _is_fast_service(entry):
            continue
        if not entry:
            snapshot = config.get('snapshots', {}).get(channel_id, {})
            if _is_fast_service(snapshot):
                continue
        resolved_id = entry.get('id') if entry else channel_id
        if resolved_id not in seen:
            canonical.append(resolved_id)
            seen.add(resolved_id)
    # Elimina también los metadatos antiguos de fuentes FAST que ya no forman
    # parte del ámbito latino permitido; no reaparecerán como elementos
    # obsoletos en Mis canales después de actualizar.
    for old_id in list(config.get('snapshots', {})):
        if old_id not in canonical and _is_fast_service(config['snapshots'].get(old_id, {})):
            config['snapshots'].pop(old_id, None)
    if canonical != config.get('selected', []) or config.get('snapshots', {}) != original_snapshots:
        config['selected'] = canonical
        try:
            save_config(config)
        except Exception as exc:
            log('No se pudo actualizar la selección al consolidar canales: {0}'.format(exc), xbmc.LOGWARNING)
    return result


_FAST_SERVICE_RE = re.compile(
    r"\b(?:rakuten|rakunten)(?:\s*tv)?\b|"
    r"\b(?:runtime|run\s*time)(?:\s*tv)?\b|"
    r"\blg\s*(?:channels?|canales?)(?:\s*tv)?\b|"
    r"\b(?:samsung\s*tv\s*plus|samsungtvplus|sam\s*tv\s*plus)\b|"
    r"\b(?:whale\s*tv(?:\s*plus)?|whaletvplus)\b|"
    r"\b(?:pluto\s*tv|plex(?:\s*tv)?|tubi(?:\s*tv)?|freevee|"
    r"xumo(?:\s*play)?|rlaxx|waipu|the\s*roku\s*channel)\b", re.I)


def _entry_search_text(entry):
    return clean_display_name(' '.join(
        [entry.get('name', ''), entry.get('original_name', '')] +
        list(entry.get('path') or []) +
        [part for path in entry.get('alternate_paths', []) for part in path] +
        [entry.get('region', '')]
    ))


def _is_fast_service(entry):
    """Detecta servicios FAST/proveedores excluidos o fuentes filtradas."""
    return bool(entry.get('excluded_source')) or bool(_FAST_SERVICE_RE.search(_entry_search_text(entry)))


_CATEGORY_RULES = [
    ('Deportes', re.compile(r'\b(sport|sports|espn|fox\s*sports?|dsports?|dazn|tnt\s*sport|win\s*sport|tyc|gol\s*tv|futbol|fútbol|formula\s*1|ufc|nba|nfl|mlb|wwe|motor)\b', re.I)),
    ('Películas', re.compile(r'\b(cine|cinema|movie|pel[ií]cula|film|hbo|cinemax|paramount\s*channel|studio|amc|universal\s*(?:cinema|premiere)|star\s*channel)\b', re.I)),
    ('Series y entretenimiento', re.compile(r'\b(series|serie|comedy|comed[y]?|comedia|entreten|warner|fox|axn|sony|fx|syfy|e!|tlc|discovery|history|historia|investigation|crime|reality|novela|telenovela)\b', re.I)),
    ('Noticias', re.compile(r'\b(news|noticias|cnn|bbc|ntn|24\s*horas|teleSUR|euronews|france\s*24|dw\s*news|foro\s*tv)\b', re.I)),
    ('Infantiles', re.compile(r'\b(kids|junior|ni[nñ]os|infantil|disney|nick(?:elodeon)?|cartoon|boomerang|baby\s*tv|paka\s*paka)\b', re.I)),
    ('Música', re.compile(r'\b(music|m[uú]sica|mtv|vh1|vevo|concert|concierto|ritmo|telehit|htv)\b', re.I)),
]


def _channel_category(entry):
    text = _entry_search_text(entry)
    for category, pattern in _CATEGORY_RULES:
        if pattern.search(text):
            return category
    return 'General'

def _add_selected_channel(entry, channel_id, selected_count, snapshot=None):
    label = _channel_label(entry)
    context = [
        ('Cambiar fuente', 'RunPlugin({0})'.format(plugin_url('channel_sources', id=channel_id))),
        ('Eliminar de Mis canales', 'RunPlugin({0})'.format(plugin_url('remove', id=channel_id))),
    ]
    item = xbmcgui.ListItem(label=label)
    art = {}
    if entry.get('thumbnail'):
        art.update({'thumb': entry['thumbnail'], 'icon': entry['thumbnail']})
    if entry.get('fanart'):
        art['fanart'] = entry['fanart']
    if art:
        item.setArt(art)
    item.setInfo('video', {'title': label, 'plot': entry.get('info', '')})
    # Esta entrada ejecuta un script que mantiene su propio xbmc.Player y una
    # lista de canales. Por eso debe ser una carpeta de acción, no un elemento
    # reproducible que Kodi espere resolver con setResolvedUrl().
    item.addContextMenuItems(context)
    xbmcplugin.addDirectoryItem(HANDLE, plugin_url('play', id=channel_id), item, True, selected_count)


def _category_view(root, config, category):
    xbmcplugin.setPluginCategory(HANDLE, category)
    entry_map = _catalog_entry_map(root, config)
    selected = []
    for channel_id in config.get('selected', []):
        entry = entry_map.get(channel_id)
        if entry and not _is_fast_service(entry) and _channel_category(entry) == category:
            selected.append((channel_id, entry))
    for channel_id, entry in selected:
        _add_selected_channel(entry, channel_id, len(selected))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def home(root=None, config=None):
    config = config or load_config()
    if root is None:
        root, _source = load_catalog()
    xbmcplugin.setPluginCategory(HANDLE, 'Mis canales')
    if not config.get('setup_complete'):
        add_directory('Configurar mis canales', plugin_url('wizard'), ADDON.getAddonInfo('icon'))
    else:
        entry_map = _catalog_entry_map(root, config)
        visible = []
        missing = []
        for channel_id in config.get('selected', []):
            entry = entry_map.get(channel_id)
            if entry:
                if not _is_fast_service(entry):
                    visible.append((channel_id, entry))
            else:
                snapshot = config.get('snapshots', {}).get(channel_id, {})
                missing.append((channel_id, snapshot))

        # Mis canales siempre es una sola lista continua, en el orden elegido
        # por el usuario. Las categorías se reservan exclusivamente al catálogo
        # general de selección.
        for channel_id, entry in visible:
            _add_selected_channel(entry, channel_id, len(visible))

        # Mantener accesibles las selecciones antiguas que ya no aparecen en catálogo.
        for channel_id, snapshot in missing:
            old_name = snapshot.get('name', 'Canal') + '  [no disponible en el catálogo]'
            item = xbmcgui.ListItem(label=old_name)
            if snapshot.get('thumbnail'):
                item.setArt({'thumb': snapshot['thumbnail'], 'icon': snapshot['thumbnail']})
            item.setInfo('video', {'title': old_name, 'plot': 'Este canal ya no aparece en la versión actual del catálogo. La selección se conserva.'})
            item.addContextMenuItems([('Eliminar de Mis canales', 'RunPlugin({0})'.format(plugin_url('remove', id=channel_id)))])
            xbmcplugin.addDirectoryItem(HANDLE, plugin_url('missing', id=channel_id), item, False)

        hidden_count = len(config.get('selected', [])) - len(visible) - len(missing)
        if hidden_count > 0:
            log('Se ocultaron {0} canales de plataformas FAST'.format(hidden_count))

    add_directory('Explorar catálogo', plugin_url('catalog'), ADDON.getAddonInfo('icon'), description='Busca canales por categoría y agrégalos a Mis canales.')
    add_directory('Administrar canales', plugin_url('manage'), ADDON.getAddonInfo('icon'))
    add_directory('Actualizar catálogo', plugin_url('refresh'), ADDON.getAddonInfo('icon'))
    add_directory('Configuración', plugin_url('settings'), ADDON.getAddonInfo('icon'))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)

def manage(root, config):
    xbmcplugin.setPluginCategory(HANDLE, 'Administrar canales')
    add_directory('Organizar todos los canales y fuentes', plugin_url('organize'))
    add_directory('Explorar catálogo general', plugin_url('catalog'))
    add_directory('Eliminar canales', plugin_url('remove_select'))
    add_directory('Volver a ejecutar el asistente inicial', plugin_url('wizard'))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)




def _organizer_region_layout(root, config):
    load_manual_groups()
    region = config.get('region', '')
    entries = extract_region_channels(root, region, fetcher=load_external_catalog) if region else []
    entries = [entry for entry in entries if not _is_fast_service(entry)]
    data = _read_organizer()
    if region not in data['regions']:
        channels = []
        for entry in entries:
            sources = [_source_uid(src) for src in _expand_sources(entry)]
            if sources:
                channels.append({
                    'id': entry.get('id'),
                    'name': _channel_label(entry),
                    'sources': sources,
                    'thumbnail': entry.get('thumbnail', ''),
                })
        data['regions'][region] = {'channels': channels}
        _write_organizer(data)
    layout = data['regions'].get(region, {}).get('channels', [])
    # Incorporar canales/fuentes recién aparecidos sin alterar agrupaciones manuales.
    known = set(uid for ch in layout for uid in ch.get('sources', []))
    changed = False
    for entry in entries:
        fresh = [src for src in _expand_sources(entry) if _source_uid(src) not in known]
        if fresh:
            record = next((ch for ch in layout if ch.get('id') == entry.get('id')), None)
            if record is None:
                record = {'id': entry.get('id'), 'name': _channel_label(entry),
                          'sources': [], 'thumbnail': entry.get('thumbnail', '')}
                layout.append(record)
            record['sources'].extend(_source_uid(src) for src in fresh)
            known.update(_source_uid(src) for src in fresh)
            changed = True
    # Quitar referencias a fuentes que ya no existen en el catálogo.
    current = set(_source_uid(src) for entry in entries for src in _expand_sources(entry))
    for record in layout:
        before = list(record.get('sources', []))
        record['sources'] = [uid for uid in before if uid in current]
        if before != record['sources']:
            changed = True
    layout[:] = [ch for ch in layout if ch.get('sources')]
    if changed:
        _write_organizer(data)
    return entries, data, layout


def _organizer_source_map(entries):
    result = {}
    for entry in entries:
        for source in _expand_sources(entry):
            result.setdefault(_source_uid(source), (entry, source))
    return result


def _organizer_home(root, config):
    entries, data, layout = _organizer_region_layout(root, config)
    if not entries:
        xbmcgui.Dialog().ok(ADDON_NAME, 'No hay canales disponibles en la región seleccionada.')
        manage(root, config)
        return
    xbmcplugin.setPluginCategory(HANDLE, 'Organizar todos los canales y fuentes')
    add_directory('Restaurar la organización anterior', plugin_url('org_undo'))
    for index, record in enumerate(layout):
        label = record.get('name', 'Canal')
        add_directory('{0}  ({1} fuentes)'.format(label, len(record.get('sources', []))),
                      plugin_url('org_channel', index=index))
    add_directory('Volver a Administración', plugin_url('manage'))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def _organizer_channel(root, config, index):
    entries, data, layout = _organizer_region_layout(root, config)
    if index < 0 or index >= len(layout):
        _organizer_home(root, config)
        return
    record = layout[index]
    source_map = _organizer_source_map(entries)
    options = [
        'Ver / probar una fuente',
        'Cambiar nombre del canal',
        'Mover una fuente de otro canal a este',
        'Agrupar otro canal completo con este',
        'Separar una fuente y crear un canal independiente',
        'Subir este canal',
        'Bajar este canal',
    ]
    choice = xbmcgui.Dialog().select(record.get('name', 'Canal'), options)
    if choice == 0:
        _organizer_sources(root, config, index)
        return
    if choice == 1:
        new_name = xbmcgui.Dialog().input('Nombre del canal', record.get('name', ''))
        if new_name and clean_display_name(new_name):
            record['name'] = clean_display_name(new_name)
            _write_organizer(data)
            notify('Nombre guardado')
    elif choice == 2:
        candidates = [(ci, ch, uid) for ci, ch in enumerate(layout) if ci != index
                      for uid in ch.get('sources', [])]
        if not candidates:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No hay otras fuentes disponibles.')
        else:
            labels = []
            for ci, ch, uid in candidates:
                pair = source_map.get(uid)
                src = pair[1] if pair else {}
                labels.append('{0} · {1} [{2}]'.format(ch.get('name', 'Canal'),
                    src.get('kind', 'Fuente'), _source_host(src)))
            chosen = xbmcgui.Dialog().select('Selecciona la fuente que quieres mover', labels)
            if chosen >= 0:
                other_index, other, uid = candidates[chosen]
                other['sources'].remove(uid)
                record.setdefault('sources', []).append(uid)
                if not other['sources']:
                    layout.pop(other_index)
                _write_organizer(data)
                notify('Fuente movida al canal seleccionado')
    elif choice == 3:
        candidates = [(i, ch) for i, ch in enumerate(layout) if i != index]
        if not candidates:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No hay otros canales para agrupar.')
        else:
            chosen = xbmcgui.Dialog().select('Selecciona el canal que quieres agrupar',
                ['{0} ({1} fuentes)'.format(ch.get('name', 'Canal'), len(ch.get('sources', [])))
                 for _, ch in candidates])
            if chosen >= 0:
                other_index, other = candidates[chosen]
                record.setdefault('sources', []).extend(
                    uid for uid in other.get('sources', []) if uid not in record.get('sources', []))
                layout.pop(other_index)
                _write_organizer(data)
                notify('Canales agrupados manualmente')
    elif choice == 4:
        ids = list(record.get('sources', []))
        names = []
        for uid in ids:
            pair = source_map.get(uid)
            src = pair[1] if pair else {}
            names.append('{0} · {1}'.format(src.get('kind', 'Fuente'), _source_host(src)))
        selected = xbmcgui.Dialog().select('Selecciona la fuente que quieres separar', names)
        if selected >= 0:
            uid = ids[selected]
            new_name = xbmcgui.Dialog().input('Nombre del nuevo canal', record.get('name', '') + ' – Señal 2')
            if new_name and clean_display_name(new_name):
                record['sources'].remove(uid)
                layout.append({'id': 'manual-' + uid[:16], 'name': clean_display_name(new_name),
                               'sources': [uid], 'thumbnail': record.get('thumbnail', '')})
                _write_organizer(data)
                notify('Fuente separada en un canal independiente')
    elif choice in (5, 6):
        target = max(0, index - 1) if choice == 5 else min(len(layout) - 1, index + 1)
        if target != index:
            layout[index], layout[target] = layout[target], layout[index]
            _write_organizer(data)
            notify('Orden de canales actualizado')
    _organizer_home(root, load_config())


def _source_host(source):
    try:
        parsed = urllib.parse.urlsplit((source.get('url') or '').split('|', 1)[0])
        return parsed.netloc or source.get('kind', 'fuente')
    except Exception:
        return source.get('kind', 'fuente')


def _organizer_sources(root, config, index):
    entries, data, layout = _organizer_region_layout(root, config)
    if index < 0 or index >= len(layout):
        _organizer_home(root, config)
        return
    record = layout[index]
    source_map = _organizer_source_map(entries)
    ids = list(record.get('sources', []))
    last_tested_uid = data.get('regions', {}).get(config.get('region', ''), {}).get('last_tested_source', '')
    xbmcplugin.setPluginCategory(HANDLE, 'Fuentes de ' + record.get('name', 'Canal'))
    for uid in ids:
        pair = source_map.get(uid)
        if not pair:
            continue
        source = pair[1]
        label = '{0} [{1}]'.format(source.get('kind', 'Fuente'), _source_host(source))
        if uid == last_tested_uid:
            label = '▶ ÚLTIMA PROBADA · ' + label
        context = [
            ('Probar fuente', 'RunPlugin(' + plugin_url('org_source_play', index=index, uid=uid) + ')'),
            ('Mover a otro canal', 'RunPlugin(' + plugin_url('org_source_move', index=index, uid=uid) + ')'),
            ('Quitar del organizador', 'RunPlugin(' + plugin_url('org_source_remove', index=index, uid=uid) + ')'),
        ]
        add_directory(label, plugin_url('org_source_play', index=index, uid=uid),
                      icon=record.get('thumbnail', ''), description=source.get('url', ''), context=context)
    add_directory('Subir prioridad de una fuente', plugin_url('org_source_reorder', index=index, direction='up'))
    add_directory('Bajar prioridad de una fuente', plugin_url('org_source_reorder', index=index, direction='down'))
    add_directory('Volver al canal', plugin_url('org_channel', index=index))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def _organizer_source_play(root, config, index, uid):
    entries, data, layout = _organizer_region_layout(root, config)
    if index < 0 or index >= len(layout) or uid not in layout[index].get('sources', []):
        _organizer_sources(root, config, index)
        return
    pair = _organizer_source_map(entries).get(uid)
    if not pair:
        _organizer_sources(root, config, index)
        return
    record = layout[index]
    data.setdefault('regions', {}).setdefault(config.get('region', ''), {})['last_tested_source'] = uid
    _write_organizer(data)
    try:
        play_sources(record.get('name', 'Prueba'), record.get('thumbnail', ''), [pair[1]],
                     auto_retry=False, notify=(ADDON.getSetting('show_notifications') != 'false'))
    except Exception as exc:
        xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo reproducir la fuente.', str(exc))
    _organizer_sources(root, load_config(), index)


def _organizer_source_move(root, config, index, uid):
    entries, data, layout = _organizer_region_layout(root, config)
    if index < 0 or index >= len(layout) or uid not in layout[index].get('sources', []):
        _organizer_home(root, config)
        return
    candidates = [(i, ch) for i, ch in enumerate(layout) if i != index]
    if not candidates:
        xbmcgui.Dialog().ok(ADDON_NAME, 'No hay otros canales de destino. Crea primero otro canal.')
        _organizer_sources(root, config, index)
        return
    chosen = xbmcgui.Dialog().select('Mover fuente a qué canal',
        ['{0} ({1} fuentes)'.format(ch.get('name', 'Canal'), len(ch.get('sources', []))) for _, ch in candidates])
    if chosen >= 0:
        target_index, target = candidates[chosen]
        layout[index]['sources'].remove(uid)
        target.setdefault('sources', []).append(uid)
        if not layout[index]['sources']:
            layout.pop(index)
            if target_index > index:
                target_index -= 1
        _write_organizer(data)
        notify('Fuente movida al canal seleccionado')
        _organizer_sources(root, load_config(), target_index)
    else:
        _organizer_sources(root, config, index)


def _organizer_source_remove(root, config, index, uid):
    entries, data, layout = _organizer_region_layout(root, config)
    if index < 0 or index >= len(layout):
        _organizer_home(root, config)
        return
    record = layout[index]
    if uid in record.get('sources', []) and xbmcgui.Dialog().yesno(
            ADDON_NAME, '¿Quitar esta fuente del organizador?\nNo se eliminará del catálogo original.'):
        record['sources'].remove(uid)
        if not record['sources']:
            layout.pop(index)
            _write_organizer(data)
            notify('Fuente retirada del organizador')
            _organizer_home(root, load_config())
            return
        _write_organizer(data)
        notify('Fuente retirada del organizador')
    _organizer_sources(root, load_config(), min(index, max(0, len(layout)-1)))


def _organizer_source_reorder(root, config, index, direction):
    entries, data, layout = _organizer_region_layout(root, config)
    if index < 0 or index >= len(layout):
        _organizer_home(root, config)
        return
    ids = list(layout[index].get('sources', []))
    if ids:
        source_map = _organizer_source_map(entries)
        labels = []
        for uid in ids:
            pair = source_map.get(uid)
            source = pair[1] if pair else {}
            labels.append('{0} [{1}]'.format(source.get('kind', 'Fuente'), _source_host(source)))
        selected = xbmcgui.Dialog().select('Selecciona la fuente', labels)
        if selected >= 0:
            target = max(0, selected-1) if direction == 'up' else min(len(ids)-1, selected+1)
            if target != selected:
                ids[selected], ids[target] = ids[target], ids[selected]
                layout[index]['sources'] = ids
                _write_organizer(data)
                notify('Prioridad de fuentes actualizada')
    _organizer_sources(root, load_config(), index)


def _organizer_undo(root, config):
    if not os.path.isfile(ORGANIZER_BACKUP_FILE):
        xbmcgui.Dialog().ok(ADDON_NAME, 'Todavía no hay una organización anterior para restaurar.')
    elif xbmcgui.Dialog().yesno(ADDON_NAME, '¿Restaurar la organización anterior? Se perderán los últimos cambios manuales.'):
        try:
            shutil.copy2(ORGANIZER_BACKUP_FILE, ORGANIZER_FILE)
            notify('Organización anterior restaurada')
        except Exception as exc:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo restaurar la copia.', str(exc))
    _organizer_home(root, load_config())


def _catalog_categories(entries):
    groups = {}
    for entry in entries:
        if _is_fast_service(entry):
            continue
        groups.setdefault(_channel_category(entry), []).append(entry)
    order = ['Deportes', 'Películas', 'Series y entretenimiento', 'Noticias', 'Infantiles', 'Música', 'General']
    return [(name, groups[name]) for name in order if groups.get(name)]


def catalog_home(root, config):
    if not config.get('region'):
        xbmcgui.Dialog().ok(ADDON_NAME, 'Primero selecciona una región.')
        return
    entries = get_region_channels(root, config.get('region', ''))
    xbmcplugin.setPluginCategory(HANDLE, 'Catálogo general')
    add_directory('Buscar canales por nombre', plugin_url('search_catalog'))
    for category, items in _catalog_categories(entries):
        add_directory('{0} ({1})'.format(category, len(items)),
                      plugin_url('catalog_category', name=category))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def catalog_category(root, config, category):
    entries = get_region_channels(root, config.get('region', ''))
    chosen = [e for e in entries if not _is_fast_service(e) and _channel_category(e) == category]
    xbmcplugin.setPluginCategory(HANDLE, 'Catálogo general / ' + category)
    for entry in chosen:
        label = _channel_label(entry)
        item = xbmcgui.ListItem(label=label)
        if entry.get('thumbnail'):
            item.setArt({'thumb': entry['thumbnail'], 'icon': entry['thumbnail']})
        item.setInfo('video', {'title': label, 'plot': 'Agregar este canal a Mis canales'})
        item.addContextMenuItems([('Agregar a Mis canales', 'RunPlugin({0})'.format(plugin_url('catalog_add', id=entry['id'])))])
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url('catalog_add', id=entry['id']), item, True)
    add_directory('Buscar en el catálogo', plugin_url('search_catalog'))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def catalog_search(root, config):
    query = xbmcgui.Dialog().input('Buscar canal por nombre', '')
    if not query:
        catalog_home(root, config)
        return
    needle = clean_display_name(query).casefold()
    entries = get_region_channels(root, config.get('region', ''))
    matches = [e for e in entries if not _is_fast_service(e) and needle in _entry_search_text(e).casefold()]
    xbmcplugin.setPluginCategory(HANDLE, 'Resultados: ' + query)
    for entry in matches:
        label = _channel_label(entry)
        item = xbmcgui.ListItem(label=label)
        if entry.get('thumbnail'):
            item.setArt({'thumb': entry['thumbnail'], 'icon': entry['thumbnail']})
        item.setInfo('video', {'title': label, 'plot': 'Agregar este canal a Mis canales'})
        item.addContextMenuItems([('Agregar a Mis canales', 'RunPlugin({0})'.format(plugin_url('catalog_add', id=entry['id'])))])
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url('catalog_add', id=entry['id']), item, True)
    if not matches:
        add_directory('No se encontraron canales con ese nombre', plugin_url('search_catalog'))
    add_directory('Buscar otra vez', plugin_url('search_catalog'))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def catalog_add(root, config, channel_id):
    entries = get_region_channels(root, config.get('region', ''))
    entry = next((e for e in entries if e.get('id') == channel_id), None)
    if not entry or _is_fast_service(entry):
        xbmcgui.Dialog().ok(ADDON_NAME, 'Ese canal no está disponible para agregar.')
        return
    entry_map = _catalog_entry_map(root, config)
    canonical_id = entry.get('id')
    selected = list(config.get('selected', []))
    selected_entries = [entry_map.get(item_id) for item_id in selected]
    already_selected = any(item and item.get('id') == canonical_id for item in selected_entries)
    if not already_selected:
        selected.append(canonical_id)
        config['selected'] = selected
        _store_snapshots(config, [entry])
        save_config(config)
        notify('Agregado: ' + _channel_label(entry))
    else:
        notify('Ese canal ya está en Mis canales')


def remove_channels(config, ids=None):
    current = list(config.get('selected', []))
    if ids is None:
        if not current:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No hay canales seleccionados.')
            return
        names = []
        for channel_id in current:
            snap = config.get('snapshots', {}).get(channel_id, {})
            label = snap.get('name', 'Canal')
            if snap.get('zone'):
                label += ' — ' + snap['zone']
            names.append(label)
        indexes = xbmcgui.Dialog().multiselect('Selecciona los canales que deseas eliminar', names)
        if indexes is None:
            return
        ids = [current[i] for i in indexes if 0 <= i < len(current)]
    remove_set = set(ids)
    config['selected'] = [channel_id for channel_id in current if channel_id not in remove_set]
    save_config(config)
    notify('Canales eliminados')


def refresh_catalog():
    try:
        root, source = load_catalog(force=True)
        regions = list_regions(root)
        # No descargar todas las listas externas en segundo plano; se refrescan
        # al entrar en cada región y se mantienen sus cachés por separado.
        if source == 'remote':
            # Solo invalidar sublistas cuando se confirmó una descarga nueva.
            # Si la actualización falla, conservar también las cachés externas.
            try:
                if os.path.isdir(SOURCE_CACHE_DIR):
                    shutil.rmtree(SOURCE_CACHE_DIR)
            except Exception as cache_exc:
                log('No se pudo limpiar caché externa tras actualizar: {0}'.format(cache_exc), xbmc.LOGWARNING)
            notify('Catálogo actualizado: {0} regiones originales'.format(len(regions)), 6000)
        else:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo descargar una versión nueva. Se conserva el catálogo local y sus listas guardadas.')
        return root
    except Exception as exc:
        log('Error al actualizar catálogo: {0}'.format(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo actualizar el catálogo.', str(exc))
        return None


def settings_menu():
    xbmcplugin.setPluginCategory(HANDLE, 'Configuración')
    add_directory('Abrir preferencias de reproducción', plugin_url('open_settings'))
    add_directory('Borrar caché del catálogo', plugin_url('clear_catalog_cache'))
    add_directory('Borrar caché de fuentes', plugin_url('clear_source_cache'))
    add_directory('Restablecer historial de señales', plugin_url('reset_health'))
    add_directory('Grupos manuales de canales (cómo usarlos)', plugin_url('groups_help'))
    add_directory('Restaurar configuración inicial', plugin_url('reset'))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def groups_help():
    """Crea una plantilla de grupos manuales y explica dónde editarla."""
    try:
        if not os.path.isfile(GROUPS_FILE):
            with open(GROUPS_FILE, 'w', encoding='utf-8') as stream:
                stream.write(GROUPS_TEMPLATE)
    except Exception as exc:
        xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo crear la plantilla.', str(exc))
        return
    xbmcgui.Dialog().ok(
        ADDON_NAME,
        'Edita este archivo para unir canales que son la misma señal:\n{0}\n\n'
        'Ejemplo (entre las llaves):\n'
        '\"ESPN 2\": [\"ESPN 2 Latino\", \"ESPN2 Alterno\"]\n'
        'Varios grupos se separan con coma. Escribe los nombres sin zona ni '
        'calidad (HD). Después reabre el complemento.'.format(GROUPS_FILE))


def _expand_sources(entry):
    # Las carpetas externallink se resuelven antes, al construir el catálogo.
    # Aquí solo se devuelven las fuentes pertenecientes a este canal/variante.
    unique = []
    markers = set()
    for source in entry.get('sources', []):
        key = (source.get('kind'), source.get('url'))
        if key not in markers:
            markers.add(key)
            unique.append(source)
    return unique



def _source_health_label(source):
    """Semáforo basado en el historial real de reproducción de cada fuente."""
    try:
        key = health.source_key(source)
        record = health._load().get(key, {})
        ok = float(record.get('ok', 0) or 0)
        failures = float(record.get('fail', 0) or 0)
        total = ok + failures
        if total < 2:
            return '⚪ Sin historial suficiente ({0} intentos)'.format(int(total))
        rate = (ok + 1.0) / (total + 2.0)
        # El indicador describe el historial acumulado, no garantiza que el
        # enlace esté activo en este instante. Se muestran también los conteos
        # para que el usuario pueda interpretar la señal.
        if failures >= 3 and rate < 0.45:
            state = '🔴 Inestable'
        elif failures > 0 and rate < 0.78:
            state = '🟡 Con interrupciones'
        elif ok >= 2 and rate >= 0.78:
            state = '🟢 Estable'
        else:
            state = '🟡 En observación'
        return '{0} · {1} ok / {2} fallos'.format(state, int(ok), int(failures))
    except Exception:
        return '⚪ Sin datos'


def channel_sources(root, config, channel_id):
    """Muestra directamente las fuentes del canal seleccionado en Mis canales."""
    entry = _catalog_entry_map(root, config).get(channel_id)
    if not entry:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Este canal ya no aparece en el catálogo actual.')
        return
    sources = _expand_sources(entry)
    if not sources:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Este canal no contiene fuentes disponibles.')
        return
    labels = []
    for index, source in enumerate(sources):
        kind = source.get('kind', 'Fuente')
        host = _source_host(source)
        labels.append('{0}. {1} [{2}]  {3}'.format(
            index + 1, kind, host, _source_health_label(source)))
    selected = xbmcgui.Dialog().select(
        'Cambiar fuente · ' + _channel_label(entry), labels)
    if selected < 0:
        return
    chosen = sources[selected]
    try:
        play_sources(
            _channel_label(entry), entry.get('thumbnail', ''), [chosen],
            auto_retry=False,
            notify=(ADDON.getSetting('show_notifications') != 'false'))
    except Exception as exc:
        log('Error al cambiar fuente: {0}'.format(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo reproducir la fuente elegida.', str(exc))


def play_channel(root, config, channel_id):
    entry_map = _catalog_entry_map(root, config)
    entry = entry_map.get(channel_id)
    if not entry:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Este canal ya no aparece en el catálogo actual.')
        return
    sources = _expand_sources(entry)
    if not sources:
        xbmcgui.Dialog().ok(ADDON_NAME, 'El canal no contiene fuentes que se puedan reproducir.')
        return

    # Guardar el canal actual para permitir cambiar calidad desde el OSD
    # mediante el acceso directo de Magellan AutoPlay.
    config['current_playing_channel'] = channel_id
    save_config(config)

    try:
        # Construir la secuencia en el orden de 'Mis canales'. Así Kodi puede
        # cambiar de canal con PlayerControl(Next/Previous) sin salir del video.
        selected_entries = []
        for selected_id in config.get('selected', []):
            selected_entry = entry_map.get(selected_id)
            if selected_entry and not _is_fast_service(selected_entry):
                selected_sources = _expand_sources(selected_entry)
                if selected_sources:
                    selected_entries.append({
                        'name': _channel_label(selected_entry),
                        'thumbnail': selected_entry.get('thumbnail', ''),
                        'sources': selected_sources,
                    })
        start_index = 0
        for i, selected_id in enumerate(config.get('selected', [])):
            if selected_id == channel_id:
                # El índice se recalcula en la lista realmente reproducible.
                target_name = _channel_label(entry)
                for j, channel in enumerate(selected_entries):
                    if channel.get('name') == target_name:
                        start_index = j
                        break
                break
        if selected_entries:
            play_channel_sequence(
                selected_entries, start_index=start_index,
                notify=(ADDON.getSetting('show_notifications') != 'false'))
        else:
            play_sources(
                _channel_label(entry), entry.get('thumbnail', ''), sources,
                auto_retry=(ADDON.getSetting('auto_retry') != 'false'),
                notify=(ADDON.getSetting('show_notifications') != 'false'),
            )
    except Exception as exc:
        log('No fue posible reproducir {0}: {1}'.format(entry.get('name'), exc), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo reproducir este canal.', str(exc))
    finally:
        # Al detener el video, volver siempre a la lista principal Mis canales.
        # Action(Back) dependía de la pantalla desde la que se inició la acción
        # y podía regresar a Administración o salir del complemento.
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        except Exception:
            pass
        try:
            xbmc.sleep(200)
            xbmc.executebuiltin('Container.Update({0},replace)'.format(plugin_url('home')))
        except Exception as nav_exc:
            log('No se pudo volver a Mis canales: {0}'.format(nav_exc), xbmc.LOGWARNING)


def _remove_quality_keymap():
    """Retira el atajo Ctrl+Q que instalaban versiones anteriores."""
    try:
        keymap_path = os.path.join(xbmcvfs.translatePath('special://profile/keymaps'), 'Magellan_AutoPlay.xml')
        if os.path.isfile(keymap_path):
            with open(keymap_path, 'r', encoding='utf-8') as keymap_file:
                old_keymap = keymap_file.read()
            if 'action=quality_menu' in old_keymap:
                os.remove(keymap_path)
                xbmc.executebuiltin('Action(reloadkeymaps)')
    except Exception as exc:
        log('No se pudo retirar el antiguo atajo de calidad: {0}'.format(exc), xbmc.LOGWARNING)


def route():
    _remove_quality_keymap()
    params = urllib.parse.parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 and sys.argv[2] else {}
    action = params.get('action', ['home'])[0]
    config = load_config()

    if action in ('play', 'missing', 'channel_sources'):
        try:
            root, _source = load_catalog()
        except Exception as exc:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo abrir el catálogo para reproducir.', str(exc))
            return
        if action == 'play':
            play_channel(root, config, params.get('id', [''])[0])
        elif action == 'channel_sources':
            channel_sources(root, config, params.get('id', [''])[0])
        return

    # Las acciones de mantenimiento y preferencias no dependen de que el
    # servidor del catálogo esté disponible.
    if action == 'settings':
        settings_menu()
        return
    if action == 'open_settings':
        ADDON.openSettings()
        settings_menu()
        return
    if action == 'clear_catalog_cache':
        try:
            if os.path.exists(CACHE_FILE):
                os.remove(CACHE_FILE)
            notify('Caché del catálogo eliminada')
        except Exception as exc:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo borrar la caché.', str(exc))
        settings_menu()
        return
    if action == 'reset_health':
        if xbmcgui.Dialog().yesno(ADDON_NAME, '¿Borrar el historial de qué señales funcionan mejor?'):
            health.reset()
            notify('Historial de señales restablecido')
        settings_menu()
        return
    if action == 'groups_help':
        groups_help()
        settings_menu()
        return
    if action == 'clear_source_cache':
        try:
            if os.path.isdir(SOURCE_CACHE_DIR):
                shutil.rmtree(SOURCE_CACHE_DIR)
            notify('Caché de listas externas eliminada')
        except Exception as exc:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo borrar la caché de fuentes.', str(exc))
        settings_menu()
        return
    if action in ('catalog', 'catalog_category', 'search_catalog', 'catalog_add'):
        try:
            root, _source = load_catalog()
            if action == 'catalog':
                catalog_home(root, config)
            elif action == 'catalog_category':
                catalog_category(root, config, params.get('name', ['General'])[0])
            elif action == 'search_catalog':
                catalog_search(root, config)
            else:
                catalog_add(root, config, params.get('id', [''])[0])
                # Mantener al usuario dentro del catálogo tras agregar.
                catalog_home(root, load_config())
        except Exception as exc:
            log('Error en catálogo general: {0}'.format(exc), xbmc.LOGERROR)
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo abrir el catálogo general.', str(exc))
        return

    if action == 'category':
        try:
            root, _source = load_catalog()
            _category_view(root, config, params.get('name', ['General'])[0])
        except Exception as exc:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo abrir la categoría.', str(exc))
        return

    if action == 'refresh':
        updated_root = refresh_catalog()
        if updated_root is not None:
            home(updated_root, load_config())
        else:
            xbmcplugin.setPluginCategory(HANDLE, 'Magellan AutoPlay')
            add_directory('Reintentar actualizar catálogo', plugin_url('refresh'))
            add_directory('Configuración', plugin_url('settings'))
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return

    # Home intenta cargar la copia local primero; si no existe, descarga el
    # mismo catálogo fuente usado por Magellan.
    try:
        root, _source = load_catalog()
    except Exception as exc:
        log('No se pudo cargar catálogo: {0}'.format(exc), xbmc.LOGERROR)
        xbmcplugin.setPluginCategory(HANDLE, 'Magellan AutoPlay')
        add_directory('Reintentar cargar catálogo', plugin_url('refresh'))
        add_directory('Configuración', plugin_url('settings'))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        if action == 'home':
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo leer el catálogo original de Magellan.', str(exc))
        return

    if action == 'home':
        if not config.get('setup_complete'):
            # Solo se muestra el asistente automáticamente en la primera
            # apertura; si se cancela, la opción permanece en la pantalla.
            if run_wizard(root, config):
                config = load_config()
        home(root, config)
    elif action == 'wizard':
        run_wizard(root, config)
        home(root, load_config())
    elif action == 'manage':
        manage(root, config)
    elif action == 'organize':
        _organizer_home(root, config)
    elif action == 'org_channel':
        _organizer_channel(root, config, int(params.get('index', ['-1'])[0]))
    elif action == 'org_sources':
        _organizer_sources(root, config, int(params.get('index', ['-1'])[0]))
    elif action == 'org_source_play':
        _organizer_source_play(root, config, int(params.get('index', ['-1'])[0]), params.get('uid', [''])[0])
    elif action == 'org_source_move':
        _organizer_source_move(root, config, int(params.get('index', ['-1'])[0]), params.get('uid', [''])[0])
    elif action == 'org_source_remove':
        _organizer_source_remove(root, config, int(params.get('index', ['-1'])[0]), params.get('uid', [''])[0])
    elif action == 'org_source_reorder':
        _organizer_source_reorder(root, config, int(params.get('index', ['-1'])[0]), params.get('direction', ['up'])[0])
    elif action == 'org_undo':
        _organizer_undo(root, config)
    elif action == 'remove_select':
        remove_channels(config)
        home(root, load_config())
    elif action == 'remove':
        remove_channels(config, [params.get('id', [''])[0]])
        home(root, load_config())
    elif action == 'reset':
        if xbmcgui.Dialog().yesno(ADDON_NAME, '¿Borrar la selección y volver a ejecutar el asistente?'):
            config['setup_complete'] = False
            config['region'] = ''
            config['selected'] = []
            save_config(config)
            run_wizard(root, config)
        home(root, load_config())
    else:
        home(root, config)


if __name__ == '__main__':
    try:
        route()
    except Exception as exc:
        log('Error no controlado: {0}\n{1}'.format(exc, traceback.format_exc()), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, 'Se produjo un error. Revisa kodi.log.', str(exc))
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        except Exception:
            pass
