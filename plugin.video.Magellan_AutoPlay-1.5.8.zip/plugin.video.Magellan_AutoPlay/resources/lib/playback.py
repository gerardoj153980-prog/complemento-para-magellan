# -*- coding: utf-8 -*-
"""Prueba y reproduce fuentes usando los callbacks reales de Kodi."""
from __future__ import absolute_import, unicode_literals

import time
import re
import html
import uuid
import urllib.request
import urllib.parse
import xbmc
import xbmcaddon
import xbmcgui

import health


class SourcePlayer(xbmc.Player):
    def __init__(self):
        super(SourcePlayer, self).__init__()
        self.state = 'idle'
        self.state_time = time.time()
        self.start_count = 0

    def reset_state(self):
        self.state = 'idle'
        self.state_time = time.time()

    def onPlayBackStarted(self):
        self.state = 'started'
        self.state_time = time.time()
        self.start_count += 1
        # Intenta cerrar el indicador de espera de Kodi cuando el reproductor
        # confirma que el video ya comenzó. El skin puede ignorar este cierre.
        try:
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        except Exception:
            pass

    def onPlayBackError(self):
        self.state = 'error'
        self.state_time = time.time()

    def onPlayBackStopped(self):
        self.state = 'stopped'
        self.state_time = time.time()

    def onPlayBackEnded(self):
        self.state = 'ended'
        self.state_time = time.time()


def _make_list_item(name, thumbnail, source):
    item = xbmcgui.ListItem(label=name)
    if thumbnail:
        item.setArt({'thumb': thumbnail, 'icon': thumbnail})
    url = source.get('url', '')
    kind = source.get('kind', 'direct')
    lower_url = url.lower()
    manifest_type = ''
    if '.m3u8' in lower_url:
        manifest_type = 'hls'
    elif '.mpd' in lower_url or 'format=mpd' in lower_url:
        manifest_type = 'mpd'
    elif '.ism' in lower_url:
        manifest_type = 'ism'

    # Respeta la forma de reproducción de cada fuente. Magellan original
    # reserva InputStream Adaptive para enlaces marcados como inputstream
    # (o enlaces DRM). En particular, no lo fuerza sobre HLS directos: Kodi
    # puede abrirlos con su reproductor nativo y así evitar cambiar la
    # selección/interpretación de las pistas de audio.
    # DASH e ISM directos conservan ISA por compatibilidad con esos manifiestos.
    use_adaptive = (kind == 'inputstream' or '$$lic=' in url)
    if manifest_type in ('mpd', 'ism') and not use_adaptive:
        try:
            use_adaptive = bool(xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)'))
        except Exception:
            use_adaptive = False

    if manifest_type and use_adaptive:
        item.setProperty('inputstream', 'inputstream.adaptive')
        item.setProperty('inputstream.adaptive.manifest_type', manifest_type)
        if manifest_type == 'hls':
            item.setMimeType('application/vnd.apple.mpegurl')
        elif manifest_type == 'mpd':
            item.setMimeType('application/dash+xml')
        else:
            item.setMimeType('application/vnd.ms-sstr+xml')
        item.setContentLookup(False)
    if '$$lic=' in url:
        try:
            _base, license_key = url.split('$$lic=', 1)
            item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
            item.setProperty('inputstream.adaptive.license_key', license_key)
        except Exception:
            pass
    if '|' in url:
        try:
            _base, headers = url.split('|', 1)
            item.setProperty('inputstream.adaptive.stream_headers', headers)
        except Exception:
            pass
    item.setProperty('IsPlayable', 'true')
    return item


def _resolve_doregex(source):
    """Resuelve expresiones $doregex simples del XML sin ejecutar Python remoto."""
    url = source.get('url', '')
    regexes = dict((entry.get('name'), entry) for entry in source.get('regexes', []) if entry.get('name'))
    if '$doregex[' not in url:
        return source
    for _attempt in range(12):
        match = re.search(r'\$doregex\[([^\]]+)\]', url)
        if not match:
            break
        key = match.group(1)
        definition = regexes.get(key)
        if not definition:
            raise RuntimeError('Falta la definición regex "{0}" en el catálogo'.format(key))
        page = definition.get('page', '') or ''
        expression = definition.get('expres', '') or ''
        if '$doregex[' in page:
            nested = dict(source)
            nested['url'] = page
            page = _resolve_doregex(nested).get('url', '')
        if page.startswith('$pyFunction:') or expression.startswith('$pyFunction:') or '#$pyFunction' in expression:
            raise RuntimeError('Esta fuente requiere una función dinámica de Magellan que no se ejecuta desde código remoto')
        content = ''
        if page.startswith('http://') or page.startswith('https://'):
            headers = {'User-Agent': definition.get('agent') or
                       'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36'}
            header_part = ''
            if '|' in page:
                page, header_part = page.split('|', 1)
            for field, header in (('referer', 'Referer'), ('accept', 'Accept'),
                                  ('origin', 'Origin'), ('x-req', 'X-Requested-With'),
                                  ('x-addr', 'x-addr'), ('x-forward', 'X-Forwarded-For')):
                if definition.get(field):
                    headers[header] = definition[field]
            if header_part:
                for pair in header_part.split('&'):
                    if '=' in pair:
                        name, value = pair.split('=', 1)
                        headers[name] = value
            request = urllib.request.Request(page, headers=headers)
            post = None
            if definition.get('rawpost'):
                post = definition['rawpost'].encode('utf-8')
            elif definition.get('post'):
                post_values = {}
                for pair in definition['post'].split(','):
                    if ':' in pair:
                        name, value = pair.split(':', 1)
                        post_values[name] = value
                if post_values:
                    post = urllib.parse.urlencode(post_values).encode('utf-8')
            with urllib.request.urlopen(request, data=post, timeout=20) as response:
                raw = response.read()
                charset = None
                content_type = response.headers.get('Content-Type', '')
                charset_match = re.search(r'charset=([^; ]+)', content_type, re.I)
                if charset_match:
                    charset = charset_match.group(1).strip('"\'')
            content = raw.decode(charset or 'utf-8', 'replace')
        else:
            content = page
        if not page:
            # Magellan usa expres como enlace literal cuando no hay etiqueta page.
            value = expression
        elif not expression:
            value = content
        else:
            try:
                found = re.search(expression, content, re.S)
                value = found.group(1).strip() if found else ''
            except re.error as exc:
                raise RuntimeError('Expresión regex no válida ({0}): {1}'.format(key, exc))
        if definition.get('htmlunescape'):
            value = html.unescape(value)
        if not value:
            raise RuntimeError('La expresión "{0}" no devolvió una fuente'.format(key))
        url = url.replace(match.group(0), value)
    if '$doregex[' in url:
        raise RuntimeError('Demasiados niveles de expresiones regex')
    url = url.replace('$epoctime$', str(int(time.time())))
    url = url.replace('$GUID$', str(uuid.uuid1()).upper())
    result = dict(source)
    result['url'] = url
    return result


def _resolve_special(source):
    """Resuelve tipos especiales solo si el módulo opcional existe."""
    source = _resolve_doregex(source)
    kind = source.get('kind', 'direct')
    url = source.get('url', '')
    if kind == 'urlsolve':
        last_error = None
        try:
            import resolveurl
            resolved = resolveurl.resolve(url)
            if resolved:
                return {'url': resolved, 'kind': 'direct'}
        except Exception as exc:
            last_error = exc
        try:
            import urlresolver
            resolved = urlresolver.resolve(url)
            if resolved:
                return {'url': resolved, 'kind': 'direct'}
        except Exception as exc:
            last_error = exc
        raise RuntimeError('No se pudo resolver el enlace: {0}'.format(last_error or 'resolver no disponible'))
    if kind == 'slproxy':
        # La implementación de SLProxy puede variar según la versión del
        # módulo. Se intenta usar su helper de Magellan cuando está instalado.
        try:
            from dsp import streamlink_proxy
            helper = streamlink_proxy.SLProxy_Helper()
            if '$$RESOLVEONLY$$' in url:
                url = url.replace('$$RESOLVEONLY$$', '')
                q = ''
                if '$$QUALITY=' in url:
                    q = url.split('$$QUALITY=', 1)[1].split('$$', 1)[0]
                    url = url.replace('$$QUALITY=' + q + '$$', '')
                resolved = helper.resolve_url(url if not q else url + '&q=' + q)
                if resolved:
                    return {'url': resolved, 'kind': 'direct'}
            raise RuntimeError('La fuente SLProxy requiere el reproductor del módulo')
        except Exception as exc:
            raise RuntimeError('SLProxy no está disponible o no pudo resolver la fuente: {0}'.format(exc))
    if kind in ('dm', 'dmlive', 'utube', 'sportsdevil'):
        if url.startswith('plugin://'):
            return {'url': url, 'kind': 'plugin'}
        if kind == 'dm':
            return {'url': 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=' + urllib.parse.quote(url, safe=''), 'kind': 'plugin'}
        if kind == 'dmlive':
            return {'url': 'plugin://plugin.video.dailymotion_com/?mode=playLiveVideo&url=' + urllib.parse.quote(url, safe=''), 'kind': 'plugin'}
        if kind == 'utube':
            if ' ' in url:
                target = 'plugin://plugin.video.youtube/search/?q=' + urllib.parse.quote_plus(url)
            elif len(url) == 11:
                target = 'plugin://plugin.video.youtube/play/?video_id=' + url
            elif url.startswith(('PL', 'UU')):
                target = 'plugin://plugin.video.youtube/play/?playlist_id=' + url
            elif url.startswith('UC') and len(url) > 12:
                target = 'plugin://plugin.video.youtube/channel/' + url + '/'
            else:
                target = 'plugin://plugin.video.youtube/user/' + url + '/'
            return {'url': target, 'kind': 'plugin'}
        if kind == 'sportsdevil':
            target = ('plugin://plugin.video.sportsdevil/?mode=1&item=catcher%3dstreams%26url=' +
                      urllib.parse.quote(url, safe='') + '%26videoTitle=' + urllib.parse.quote('Magellan', safe=''))
            return {'url': target, 'kind': 'plugin'}
        raise RuntimeError('El elemento requiere un complemento externo no disponible')
    if kind == 'youtube-dl':
        try:
            import youtube_dl
            info = youtube_dl.YoutubeDL({'quiet': True, 'no_warnings': True}).extract_info(url, download=False)
            if info and info.get('url'):
                return {'url': info['url'], 'kind': 'direct'}
        except Exception as exc:
            raise RuntimeError('No se pudo resolver con YouTube-DL: {0}'.format(exc))
        raise RuntimeError('YouTube-DL no devolvió un enlace')
    return source


STABLE_SECONDS = 8      # una fuente cuenta como "buena" tras reproducirse así de tiempo
MAX_ROUNDS = 2          # vueltas completas por todas las fuentes antes de rendirse
END_DEBOUNCE = 1.5      # espera para distinguir un cambio de canal de un corte real


def _setting_int(name, default):
    try:
        value = int(xbmcaddon.Addon().getSetting(name) or default)
        return value if value > 0 else default
    except Exception:
        return default


def _cond(expression):
    try:
        return bool(xbmc.getCondVisibility(expression))
    except Exception:
        return False


class StreamWatch(object):
    """Vigila una reproducción en curso para detectar señales congeladas.

    Una señal se considera congelada si Kodi lleva 'stall_timeout' segundos
    cargando (buffering) sin parar, o si el tiempo de reproducción dejó de
    avanzar. La pausa y la búsqueda del usuario no cuentan. El segundo
    criterio solo se activa después de haber visto avanzar el tiempo al menos
    una vez, para no confundir fuentes que no informan su posición.
    """

    def __init__(self, stall_timeout):
        self.stall_timeout = stall_timeout
        self.started_at = time.time()
        self.last_pos = None
        self.last_change = self.started_at
        self.moved = False
        self.caching_since = None
        self.recorded = False

    def poll(self, player):
        """Devuelve 'stalled', 'stable' o None."""
        now = time.time()
        if _cond('Player.Paused') or _cond('Player.Seeking'):
            self.last_change = now
            self.caching_since = None
            return None
        try:
            pos = player.getTime()
        except Exception:
            pos = None
        if pos is not None:
            if self.last_pos is None:
                self.last_pos = pos
                self.last_change = now
            elif abs(pos - self.last_pos) > 0.2:
                self.last_pos = pos
                self.last_change = now
                self.moved = True
        caching = _cond('Player.Caching')
        if caching:
            if self.caching_since is None:
                self.caching_since = now
            elif now - self.caching_since >= self.stall_timeout:
                return 'stalled'
        else:
            self.caching_since = None
        if self.moved and now - self.last_change >= self.stall_timeout:
            return 'stalled'
        if (not self.recorded and self.moved and not caching and
                now - self.started_at >= STABLE_SECONDS):
            return 'stable'
        return None


class _SoftStop(RuntimeError):
    """Parada antes de iniciar: se reintenta, pero no penaliza la fuente."""


def play_sources(name, thumbnail, sources, auto_retry=True, notify=True, startup_timeout=None):
    """Reproduce un canal probando primero la fuente con mejor historial.

    Si una fuente falla al iniciar, da error o se congela, se pasa a la
    siguiente. Cada resultado se anota en el historial de salud.
    """
    player = SourcePlayer()
    monitor = xbmc.Monitor()
    if not sources:
        raise RuntimeError('Este canal no contiene fuentes reproducibles.')
    startup_timeout = startup_timeout or _setting_int('startup_timeout', 25)
    stall_timeout = _setting_int('stall_timeout', 20)

    queue = health.rank_sources(sources)
    index = 0
    last_error = ''
    while index < len(queue):
        raw_source = queue[index]
        index += 1
        penalize = True
        try:
            source = _resolve_special(raw_source)
            url = source.get('url', '')
            if '$$LSDirect$$' in url:
                url = url.replace('$$LSDirect$$', '')
                source = dict(source)
                source['url'] = url
            if not url:
                raise RuntimeError('Fuente vacía')
            try:
                if player.isPlaying():
                    player.stop()
                    xbmc.sleep(250)
            except Exception:
                pass
            player.reset_state()
            list_item = _make_list_item(name, thumbnail, source)
            if '$$lic=' in url:
                url = url.split('$$lic=', 1)[0]
            xbmc.log('[Magellan AutoPlay] Probando fuente {0}/{1} de {2} ({3})'.format(
                index, len(queue), name, health.describe(raw_source)), xbmc.LOGINFO)
            player.play(url, list_item)

            start = time.time()
            while not monitor.abortRequested():
                state = player.state
                if state == 'started' or player.isPlaying():
                    break
                if state == 'stopped':
                    penalize = False
                    raise _SoftStop('Kodi detuvo la fuente antes de iniciar')
                if state in ('error', 'ended'):
                    raise RuntimeError('Kodi no pudo iniciar la fuente')
                if time.time() - start >= startup_timeout:
                    raise RuntimeError('Tiempo de espera agotado al iniciar la fuente')
                xbmc.sleep(250)

            if monitor.abortRequested():
                return True

            watch = StreamWatch(stall_timeout)
            end_seen_at = None
            while not monitor.abortRequested():
                state = player.state
                playing = player.isPlaying()
                if state == 'error':
                    raise RuntimeError('Kodi notificó un error durante la reproducción')
                if state in ('stopped', 'ended') and not playing:
                    if end_seen_at is None:
                        end_seen_at = time.time()
                    elif time.time() - end_seen_at >= END_DEBOUNCE:
                        if state == 'ended' and watch.moved:
                            raise RuntimeError('La señal terminó inesperadamente')
                        return True
                else:
                    end_seen_at = None
                if playing:
                    result = watch.poll(player)
                    if result == 'stalled':
                        raise RuntimeError('La señal se congeló')
                    if result == 'stable' and not watch.recorded:
                        watch.recorded = True
                        health.record_success(raw_source)
                xbmc.sleep(500)
            return True
        except Exception as exc:
            last_error = str(exc)
            xbmc.log('[Magellan AutoPlay] Fuente {0} falló: {1}'.format(index, last_error), xbmc.LOGWARNING)
            if penalize:
                health.record_failure(raw_source, last_error)
            try:
                player.stop()
            except Exception:
                pass
            if not auto_retry:
                break
            if notify:
                xbmcgui.Dialog().notification('Magellan AutoPlay',
                    'La fuente falló. Probando otra...', time=2500)

    raise RuntimeError('No se pudo iniciar ninguna de las {0} fuentes. {1}'.format(
        len(sources), last_error))


def _play_url(source):
    """URL que se entrega a Player; la licencia permanece en el ListItem."""
    url = source.get('url', '') or ''
    if '$$LSDirect$$' in url:
        url = url.replace('$$LSDirect$$', '')
    if '$$lic=' in url:
        url = url.split('$$lic=', 1)[0]
    return url


def _pick_source(channel):
    """Elige la mejor fuente del canal que aún no se haya probado en este ciclo.

    Recalcula el orden con el historial actual cada vez, de modo que una
    fuente que acaba de fallar queda al final. Devuelve True si encontró una.
    """
    for source in health.rank_sources(channel['sources']):
        key = health.source_key(source)
        if key in channel['tried']:
            continue
        channel['tried'].add(key)
        try:
            resolved = _resolve_special(source)
            if resolved and _play_url(resolved):
                channel['active_raw'] = source
                channel['active_source'] = resolved
                return True
        except Exception as exc:
            xbmc.log('[Magellan AutoPlay] No se pudo resolver una fuente de {0}: {1}'.format(
                channel.get('name', 'Canal'), exc), xbmc.LOGWARNING)
            health.record_failure(source, 'no se pudo resolver: {0}'.format(exc))
    return False


def _fill_channel_playlist(playlist, channels):
    playlist.clear()
    for channel in channels:
        source = channel.get('active_source') or {}
        item = _make_list_item(channel.get('name') or 'Canal',
                               channel.get('thumbnail', ''), source)
        playlist.add(_play_url(source), item)


def _playlist_position(playlist, fallback):
    try:
        position = int(playlist.getposition())
        if position >= 0:
            return position
    except Exception:
        pass
    return fallback


def play_channel_sequence(channels, start_index=0, notify=True):
    """Reproduce canales en una lista de Kodi con cambio automático de señal.

    Cada canal reúne varias fuentes equivalentes. Se empieza por la que mejor
    historial tiene y, si falla (error, no arranca a tiempo, se congela o se
    corta), se pasa a la siguiente mejor sin salir del canal. Si se agotan
    todas, se vuelve a recorrer MAX_ROUNDS veces antes de rendirse. La lista
    sigue en Kodi para que PlayerControl(Next/Previous) cambie de canal.
    """
    if not channels:
        raise RuntimeError('No hay canales seleccionados para reproducir.')

    startup_timeout = _setting_int('startup_timeout', 25)
    stall_timeout = _setting_int('stall_timeout', 20)

    playable = []
    for original_index, original in enumerate(channels):
        channel = dict(original)
        channel['_original_index'] = original_index
        channel['sources'] = list(original.get('sources') or [])
        channel['tried'] = set()
        channel['rounds'] = 0
        channel['failover'] = False
        if not channel['sources']:
            continue
        if not _pick_source(channel):
            xbmc.log('[Magellan AutoPlay] Canal omitido: no se pudo resolver ninguna fuente de {0}'.format(
                channel.get('name', 'Canal')), xbmc.LOGWARNING)
            continue
        playable.append(channel)

    if not playable:
        raise RuntimeError('No se pudo preparar ninguna fuente de los canales seleccionados.')

    requested_index = max(0, int(start_index))
    mapped_start = next((i for i, channel in enumerate(playable)
                         if channel.get('_original_index') == requested_index), 0)
    start_index = max(0, min(mapped_start, len(playable) - 1))
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    _fill_channel_playlist(playlist, playable)
    player = SourcePlayer()
    monitor = xbmc.Monitor()

    state_box = {
        'active': start_index,
        'waiting': True,
        'wait_started': time.time(),
        'seen_starts': 0,
        'watch': StreamWatch(stall_timeout),
        'end_seen_at': None,
        # Justo tras player.play() la posición de la lista puede tardar en
        # actualizarse; no se interpreta como cambio de canal en ese lapso.
        'ignore_pos_until': time.time() + 2.0,
    }

    def clamp(position):
        return max(0, min(position, len(playable) - 1))

    def enter_channel(position):
        """El usuario cambió de canal (siguiente/anterior): nuevo ciclo."""
        state_box['active'] = position
        channel = playable[position]
        channel['tried'] = set([health.source_key(channel['active_raw'])])
        channel['rounds'] = 0
        channel['failover'] = False
        state_box['waiting'] = True
        state_box['wait_started'] = time.time()

    def switch_source(position, reason, penalize):
        """Marca la fuente actual como fallida y reproduce la siguiente mejor."""
        channel = playable[position]
        if penalize and channel.get('active_raw'):
            health.record_failure(channel['active_raw'], reason)
        xbmc.log('[Magellan AutoPlay] {0}: {1}'.format(channel.get('name', 'Canal'), reason),
                 xbmc.LOGWARNING)
        if not _pick_source(channel):
            if channel['rounds'] >= MAX_ROUNDS - 1:
                raise RuntimeError(
                    'Se agotaron las {0} opciones de transmisión de {1}.'.format(
                        len(channel['sources']), channel.get('name', 'este canal')))
            channel['rounds'] += 1
            channel['tried'] = set()
            if notify:
                try:
                    xbmcgui.Dialog().notification(
                        'Magellan AutoPlay',
                        'Ninguna señal respondió; reintentando...', time=2500)
                except Exception:
                    pass
            xbmc.sleep(3000)
            if not _pick_source(channel):
                raise RuntimeError(
                    'No fue posible reanudar ninguna opción de {0}.'.format(
                        channel.get('name', 'este canal')))
        channel['failover'] = True
        xbmc.log('[Magellan AutoPlay] Cambiando {0} a otra señal ({1}/{2})'.format(
            channel.get('name', 'Canal'), len(channel['tried']), len(channel['sources'])),
            xbmc.LOGINFO)
        if notify:
            try:
                xbmcgui.Dialog().notification(
                    'Magellan AutoPlay',
                    'La señal falló; cambiando a otra opción...', time=2200)
            except Exception:
                pass
        try:
            player.stop()
        except Exception:
            pass
        xbmc.sleep(350)
        _fill_channel_playlist(playlist, playable)
        player.reset_state()
        state_box['active'] = position
        state_box['waiting'] = True
        state_box['wait_started'] = time.time()
        state_box['end_seen_at'] = None
        state_box['ignore_pos_until'] = time.time() + 2.0
        player.play(playlist, startpos=position)

    xbmc.executebuiltin('Dialog.Close(busydialog)')
    player.reset_state()
    player.play(playlist, startpos=start_index)

    while not monitor.abortRequested():
        now = time.time()
        state = player.state
        try:
            is_playing = player.isPlaying()
        except Exception:
            is_playing = False

        position = clamp(_playlist_position(playlist, state_box['active']))
        if position != state_box['active'] and now >= state_box['ignore_pos_until']:
            enter_channel(position)

        # Kodi confirmó el inicio de una reproducción (nuevo canal o reintento).
        if player.start_count != state_box['seen_starts']:
            state_box['seen_starts'] = player.start_count
            playable[state_box['active']]['failover'] = False
            state_box['watch'] = StreamWatch(stall_timeout)
            state_box['waiting'] = False
            state_box['end_seen_at'] = None

        active = state_box['active']

        if state == 'error':
            switch_source(clamp(position), 'error de reproducción', True)
            continue

        if state_box['waiting']:
            if now - state_box['wait_started'] > startup_timeout:
                switch_source(active, 'la señal no respondió a tiempo', True)
                continue
            if state in ('stopped', 'ended') and not is_playing:
                if state_box['end_seen_at'] is None:
                    state_box['end_seen_at'] = now
                elif now - state_box['end_seen_at'] >= END_DEBOUNCE:
                    # Kodi detuvo la fuente sin llegar a iniciar: probar otra.
                    switch_source(active, 'se detuvo antes de iniciar', state == 'ended')
                    continue
            else:
                state_box['end_seen_at'] = None
            xbmc.sleep(300)
            continue

        # Reproducción en curso.
        if is_playing:
            if state in ('stopped', 'ended'):
                player.reset_state()
            state_box['end_seen_at'] = None
            result = state_box['watch'].poll(player)
            channel = playable[active]
            if result == 'stalled':
                switch_source(active, 'la señal se congeló', True)
                continue
            if result == 'stable' and not state_box['watch'].recorded:
                state_box['watch'].recorded = True
                health.record_success(channel['active_raw'])
                channel['tried'] = set([health.source_key(channel['active_raw'])])
                channel['rounds'] = 0
        elif state in ('stopped', 'ended'):
            if state_box['end_seen_at'] is None:
                state_box['end_seen_at'] = now
            elif now - state_box['end_seen_at'] >= END_DEBOUNCE:
                if state == 'ended' and state_box['watch'].moved:
                    # Una emisión en vivo no termina sola: la señal se cortó.
                    switch_source(active, 'la señal terminó inesperadamente', True)
                    continue
                # Parada normal pedida por el usuario: salir sin error.
                return True
        xbmc.sleep(300)
    return True
