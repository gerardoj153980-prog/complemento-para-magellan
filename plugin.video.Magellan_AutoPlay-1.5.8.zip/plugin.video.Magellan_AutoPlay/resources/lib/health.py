# -*- coding: utf-8 -*-
"""Memoria de salud de las fuentes (transmisiones) de cada canal.

Guarda en el perfil de Kodi cuántas veces ha funcionado o fallado cada fuente
y la ordena para que, al abrir un canal, se pruebe primero la que mejor ha
respondido. Las fuentes que fallan seguidamente entran en "enfriamiento":
se mueven al final de la cola durante un tiempo creciente, pero nunca se
descartan; si todas fallan, se siguen intentando como último recurso.
"""
from __future__ import absolute_import, unicode_literals

import hashlib
import json
import os
import re
import time
import urllib.parse

_PATH = ''
_DATA = None
_DIRTY_WRITES = 0

# Parámetros efímeros que cambian en cada solicitud y no identifican la señal.
_VOLATILE = set(['token', 'auth', 'authorization', 'sig', 'signature', 'expires',
                 'expiry', 'hdnea', 'jwt', 'session', 'sessionid', 'nonce'])

COOLDOWN_BASE = 120          # segundos tras el primer fallo seguido
COOLDOWN_MAX = 3600          # tope: 1 hora
MAX_AGE_DAYS = 45            # se olvidan fuentes sin uso en este tiempo
DECAY_AT = 24                # al superar esta cantidad de intentos se reduce el historial


def init(path):
    """Define el archivo de datos y carga el historial."""
    global _PATH, _DATA
    _PATH = path
    _DATA = None
    _load()


def _load():
    global _DATA
    if _DATA is not None:
        return _DATA
    data = {}
    if _PATH and os.path.isfile(_PATH):
        try:
            with open(_PATH, 'r', encoding='utf-8') as stream:
                loaded = json.load(stream)
            if isinstance(loaded, dict):
                data = loaded
        except Exception:
            data = {}
    cutoff = time.time() - MAX_AGE_DAYS * 86400
    data = dict((k, v) for k, v in data.items()
                if isinstance(v, dict) and v.get('last', 0) >= cutoff)
    _DATA = data
    return _DATA


def _save():
    if not _PATH or _DATA is None:
        return
    try:
        temp = _PATH + '.tmp'
        with open(temp, 'w', encoding='utf-8') as stream:
            json.dump(_DATA, stream)
        try:
            os.replace(temp, _PATH)
        except Exception:
            if os.path.exists(_PATH):
                os.remove(_PATH)
            os.rename(temp, _PATH)
    except Exception:
        pass


def source_key(source):
    """Clave estable de una fuente (tipo + URL sin credenciales efímeras)."""
    raw = (source.get('url') or '').strip()
    base, sep, headers = raw.partition('|')
    try:
        parsed = urllib.parse.urlsplit(base)
        query = [(k.casefold(), v) for k, v in
                 urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
                 if k.casefold() not in _VOLATILE]
        query.sort()
        normalized = '{0}://{1}{2}?{3}'.format(
            parsed.scheme.lower(), (parsed.netloc or '').lower(),
            re.sub(r'/+', '/', parsed.path or '/'), urllib.parse.urlencode(query))
        if not parsed.scheme:
            normalized = base
    except Exception:
        normalized = base
    text = '{0}\x1f{1}'.format(source.get('kind', 'direct'), normalized)
    return hashlib.sha1(text.encode('utf-8')).hexdigest()[:16]


def _record(key):
    data = _load()
    rec = data.get(key)
    if rec is None:
        rec = {'ok': 0.0, 'fail': 0.0, 'streak': 0, 'until': 0, 'last': 0, 'reason': ''}
        data[key] = rec
    return rec


def _decay(rec):
    total = rec['ok'] + rec['fail']
    if total > DECAY_AT:
        rec['ok'] = round(rec['ok'] / 2.0, 2)
        rec['fail'] = round(rec['fail'] / 2.0, 2)


def record_success(source):
    rec = _record(source_key(source))
    rec['ok'] += 1
    rec['streak'] = 0
    rec['until'] = 0
    rec['reason'] = ''
    rec['last'] = time.time()
    _decay(rec)
    _save()


def record_failure(source, reason=''):
    rec = _record(source_key(source))
    rec['fail'] += 1
    rec['streak'] = int(rec.get('streak', 0)) + 1
    wait = min(COOLDOWN_MAX, COOLDOWN_BASE * (2 ** (rec['streak'] - 1)))
    now = time.time()
    rec['until'] = now + wait
    rec['reason'] = (reason or '')[:80]
    rec['last'] = now
    _decay(rec)
    _save()


def score(source):
    """Tasa de éxito suavizada: una fuente sin historial vale 0.5."""
    rec = _load().get(source_key(source))
    if not rec:
        return 0.5
    return (rec['ok'] + 1.0) / (rec['ok'] + rec['fail'] + 2.0)


def in_cooldown(source):
    rec = _load().get(source_key(source))
    return bool(rec and rec.get('until', 0) > time.time())


def rank_sources(sources):
    """Devuelve las fuentes ordenadas: primero las sanas y mejor puntuadas.

    El orden original del catálogo se conserva como desempate para que el
    comportamiento sea estable (no se cambia de fuente sin motivo).
    """
    now = time.time()
    data = _load()

    def sort_key(pair):
        position, source = pair
        rec = data.get(source_key(source))
        cooling = 1 if (rec and rec.get('until', 0) > now) else 0
        value = score(source)
        return (cooling, -round(value, 2), position)

    return [source for _pos, source in sorted(enumerate(sources), key=sort_key)]


def describe(source):
    """Texto corto con el estado de una fuente (para diagnóstico)."""
    rec = _load().get(source_key(source))
    if not rec:
        return 'sin historial'
    state = 'en pausa' if rec.get('until', 0) > time.time() else 'activa'
    return '{0} · ok {1:g} / fallos {2:g}'.format(state, rec['ok'], rec['fail'])


def reset():
    global _DATA
    _DATA = {}
    _save()
