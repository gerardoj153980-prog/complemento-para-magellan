# -*- coding: utf-8 -*-
"""Magellan AutoPlay - Kodi plugin entry point."""
from __future__ import absolute_import, unicode_literals

import json
import os
import sys
import traceback
import hashlib
import re
import shutil
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = 'plugin.video.Magellan_AutoPlay'
ADDON_NAME = 'Magellan AutoPlay'
BASE_URL = sys.argv[0]
HANDLE = int(sys.argv[1])
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
if not xbmcvfs.exists(PROFILE):
    xbmcvfs.mkdirs(PROFILE)
CACHE_FILE = os.path.join(PROFILE, 'catalog.xml')
CONFIG_FILE = os.path.join(PROFILE, 'settings.json')
SOURCE_CACHE_DIR = os.path.join(PROFILE, 'source_cache')
ADDON_PATH = ADDON.getAddonInfo('path')
SEED_DIR = os.path.join(ADDON_PATH, 'resources', 'catalog_seeds')

# Copias aportadas para las mismas referencias externallink del árbol original.
# Se usan como respaldo sin crear regiones ni canales fuera del catálogo.
SEED_URLS = {
    'https://pastebin.com/raw/5jZTyKZP': 'espanhalatinos.txt',
    'https://pastebin.com/raw/7kQZWCGu': 'canaleslatinos.txt',
    'https://pastebin.com/raw/9X2F1NX8': 'canaleslatinosvariaslistas.txt',
}

LIB = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'lib')
if LIB not in sys.path:
    sys.path.insert(0, LIB)

from catalog import (CATALOG_URL, clean_display_name, extract_all_sources,
                     extract_region_channels, fetch_catalog, list_regions,
                     parse_catalog_data)
from playback import play_sources, play_channel_sequence

DEFAULT_CONFIG = {
    'setup_complete': False,
    'region': '',
    'selected': [],
    'snapshots': {},
}


def log(message, level=xbmc.LOGINFO):
    xbmc.log('[{0}] {1}'.format(ADDON_NAME, message), level)


def notify(message, time_ms=4000):
    if ADDON.getSetting('show_notifications') != 'false':
        xbmcgui.Dialog().notification(ADDON_NAME, message, ADDON.getAddonInfo('icon'), time=time_ms)


def load_config():
    config = dict(DEFAULT_CONFIG)
    try:
        with open(CONFIG_FILE, 'r', encoding='utf-8') as stream:
            stored = json.load(stream)
        if isinstance(stored, dict):
            config.update(stored)
    except Exception:
        pass
    if not isinstance(config.get('selected'), list):
        config['selected'] = []
    if not isinstance(config.get('snapshots'), dict):
        config['snapshots'] = {}
    return config


def save_config(config):
    temp_file = CONFIG_FILE + '.tmp'
    with open(temp_file, 'w', encoding='utf-8') as stream:
        json.dump(config, stream, ensure_ascii=False, indent=2, sort_keys=True)
    try:
        os.replace(temp_file, CONFIG_FILE)
    except Exception:
        if os.path.exists(CONFIG_FILE):
            os.remove(CONFIG_FILE)
        os.rename(temp_file, CONFIG_FILE)


def _ensure_dir(path):
    if not os.path.isdir(path):
        os.makedirs(path)


def _source_cache_path(url):
    digest = hashlib.sha1(url.encode('utf-8')).hexdigest()
    _ensure_dir(SOURCE_CACHE_DIR)
    return os.path.join(SOURCE_CACHE_DIR, digest + '.dat')


def _read_catalog_file(path):
    with open(path, 'rb') as stream:
        raw = stream.read()
    return parse_catalog_data(raw), raw


def _seed_path(url):
    filename = SEED_URLS.get(url)
    if not filename:
        return ''
    candidate = os.path.join(SEED_DIR, filename)
    return candidate if os.path.isfile(candidate) else ''


def load_external_catalog(url, force=False):
    """Carga sublistas de Magellan con caché y respaldo en archivos aportados."""
    cache_path = _source_cache_path(url)
    if not force and os.path.isfile(cache_path):
        try:
            return _read_catalog_file(cache_path)
        except Exception as exc:
            log('Caché externa inválida ({0}): {1}'.format(url, exc), xbmc.LOGWARNING)

    try:
        root, raw = fetch_catalog(url)
        temp_file = cache_path + '.tmp'
        with open(temp_file, 'wb') as stream:
            stream.write(raw)
        try:
            os.replace(temp_file, cache_path)
        except Exception:
            if os.path.exists(cache_path):
                os.remove(cache_path)
            os.rename(temp_file, cache_path)
        return root, raw
    except Exception as exc:
        log('No se pudo descargar lista externa {0}: {1}'.format(url, exc), xbmc.LOGWARNING)

    if os.path.isfile(cache_path):
        try:
            return _read_catalog_file(cache_path)
        except Exception:
            pass

    seed = _seed_path(url)
    if seed:
        root, raw = _read_catalog_file(seed)
        try:
            with open(cache_path, 'wb') as stream:
                stream.write(raw)
        except Exception:
            pass
        log('Se utilizó copia local de respaldo para {0}'.format(url))
        return root, raw
    raise IOError('La lista externa no está disponible y no hay copia local: {0}'.format(url))


def load_catalog(force=False):
    """Lee el catálogo principal, descodificando el envoltorio GZIP/hex Magellan."""
    if force:
        try:
            root, raw = fetch_catalog(CATALOG_URL)
            temp_file = CACHE_FILE + '.tmp'
            with open(temp_file, 'wb') as stream:
                stream.write(raw)
            try:
                os.replace(temp_file, CACHE_FILE)
            except Exception:
                if os.path.exists(CACHE_FILE):
                    os.remove(CACHE_FILE)
                os.rename(temp_file, CACHE_FILE)
            return root, 'remote'
        except Exception as exc:
            log('No se pudo actualizar el catálogo principal: {0}'.format(exc), xbmc.LOGWARNING)
            if os.path.isfile(CACHE_FILE):
                try:
                    return _read_catalog_file(CACHE_FILE)[0], 'cache'
                except Exception:
                    pass
            seed = os.path.join(SEED_DIR, 'magellan.txt')
            if os.path.isfile(seed):
                return _read_catalog_file(seed)[0], 'seed'
            raise

    if os.path.isfile(CACHE_FILE):
        try:
            return _read_catalog_file(CACHE_FILE)[0], 'cache'
        except Exception as exc:
            log('La caché principal no es válida: {0}'.format(exc), xbmc.LOGWARNING)

    try:
        root, raw = fetch_catalog(CATALOG_URL)
        with open(CACHE_FILE, 'wb') as stream:
            stream.write(raw)
        return root, 'remote'
    except Exception as exc:
        log('No se pudo descargar el catálogo principal: {0}'.format(exc), xbmc.LOGWARNING)
        seed = os.path.join(SEED_DIR, 'magellan.txt')
        if os.path.isfile(seed):
            root, raw = _read_catalog_file(seed)
            with open(CACHE_FILE, 'wb') as stream:
                stream.write(raw)
            return root, 'seed'
        raise


def get_region_channels(root, region_name):
    return extract_region_channels(root, region_name, fetcher=load_external_catalog)


def plugin_url(action, **kwargs):
    params = {'action': action}
    params.update(kwargs)
    return BASE_URL + '?' + urllib.parse.urlencode(params)


def add_directory(label, action, icon='', fanart='', description='', context=None):
    item = xbmcgui.ListItem(label=label)
    art = {}
    if icon:
        art['thumb'] = icon
        art['icon'] = icon
    if fanart:
        art['fanart'] = fanart
    if art:
        item.setArt(art)
    if description:
        item.setInfo('video', {'title': label, 'plot': description})
    if context:
        item.addContextMenuItems(context)
    xbmcplugin.addDirectoryItem(HANDLE, action, item, True)


def _display_channel_name(value):
    label = clean_display_name(value or 'Canal sin nombre')
    # Quita ordinales de fila de las listas (1.Tnt Sports), no números
    # integrados en el nombre real del canal (ESPN 1, Canal 13).
    label = re.sub(r'^\s*\d{1,3}\s*[.)]\s*', '', label)
    # Quita únicamente etiquetas técnicas habituales; conserva números y
    # calificadores geográficos como Norte, Sur, Este y Oeste.
    label = re.sub(r'\s*[-|•/]\s*(?:HD|FHD|UHD|4K|8K|SD|1080[pi]?|720[pi]?|576[pi]?|480[pi]?)(?:\s*[-|•/]?.*)?$', '', label, flags=re.I)
    label = re.sub(r'\s*\b(?:4K|8K|FHD|UHD|HD|SD|1080[pi]?|720[pi]?|576[pi]?|480[pi])\b', '', label, flags=re.I)
    label = re.sub(r'\s*\[[^]]*(?:HD|FHD|UHD|4K|1080[pi]?|720[pi]?)[^]]*\]\s*$', '', label, flags=re.I)
    return re.sub(r'\s+', ' ', label).strip(' -|•') or clean_display_name(value)


def _channel_label(entry):
    label = _display_channel_name(entry.get('name') or 'Canal sin nombre')
    zone = entry.get('zone')
    if zone and zone.casefold() not in label.casefold():
        label += ' — ' + zone
    # No mostrar la carpeta/lista de procedencia en el nombre: puede ser muy
    # extensa y no forma parte del nombre del canal. Las zonas se mantienen
    # arriba como calificadores explícitos (Norte, Sur, país, etc.).
    return label


def _confirm_selection(region_name, entries):
    labels = [_channel_label(entry) for entry in entries]
    preview = labels[:12]
    if len(labels) > 12:
        preview.append('… y {0} canales más'.format(len(labels) - 12))
    if not preview:
        preview = ['No se seleccionaron canales.']
    return xbmcgui.Dialog().yesno(
        ADDON_NAME,
        'Región: {0}'.format(clean_display_name(region_name)),
        'Canales seleccionados: {0}'.format(len(entries)),
        '\n'.join(preview),
    )


def _store_snapshots(config, entries):
    for entry in entries:
        config['snapshots'][entry['id']] = {
            'name': entry.get('name', 'Canal'),
            'original_name': entry.get('original_name', entry.get('name', 'Canal')),
            'region': entry.get('region', ''),
            'path': entry.get('path', []),
            'zone': entry.get('zone', ''),
            'thumbnail': entry.get('thumbnail', ''),
            'fanart': entry.get('fanart', ''),
        }


def _select_region(root, heading='Selecciona una región de Magellan'):
    regions = list_regions(root)
    # Este build trabaja con el catálogo latino aportado. Se conserva el
    # nombre original de Magellan y no se inventan ni renombran regiones.
    latino_regions = [r for r in regions if 'LATINOS' in (r.get('label') or clean_display_name(r.get('name', ''))).upper()]
    if latino_regions:
        regions = latino_regions
    if not regions:
        xbmcgui.Dialog().ok(ADDON_NAME, 'El catálogo no contiene regiones reconocibles.')
        return None
    index = xbmcgui.Dialog().select(heading, [r.get('label') or clean_display_name(r['name']) for r in regions])
    if index < 0:
        return None
    return regions[index]['name']


def _select_channel_ids(entries, heading, preselected=None):
    entries = [entry for entry in entries if not _is_fast_service(entry)]
    if not entries:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Esta región no contiene canales seleccionables.')
        return None
    preselected = set(preselected or [])
    options = ['Seleccionar todos', 'Deseleccionar todos', 'Elegir individualmente', 'Cancelar']
    choice = xbmcgui.Dialog().select(heading, options)
    if choice == 0:
        return [entry['id'] for entry in entries]
    if choice == 1:
        return []
    if choice != 2:
        return None

    labels = [_channel_label(entry) for entry in entries]
    preselect_indices = [i for i, entry in enumerate(entries) if entry['id'] in preselected]
    try:
        result = xbmcgui.Dialog().multiselect(heading, labels, preselect=preselect_indices)
    except TypeError:
        # Compatibilidad con implementaciones de Kodi que no aceptan preselect.
        result = xbmcgui.Dialog().multiselect(heading, labels)
    if result is None:
        return None
    return [entries[i]['id'] for i in result if 0 <= i < len(entries)]


def run_wizard(root, config=None):
    config = config or load_config()
    region_name = _select_region(root)
    if not region_name:
        return False
    entries = get_region_channels(root, region_name)
    selected_ids = _select_channel_ids(entries, 'Selecciona los canales que quieres ver')
    if selected_ids is None:
        return False
    selected_set = set(selected_ids)
    selected_entries = [entry for entry in entries if entry['id'] in selected_set]
    if not _confirm_selection(region_name, selected_entries):
        return False
    config['region'] = region_name
    config['selected'] = [entry['id'] for entry in selected_entries]
    config['setup_complete'] = True
    _store_snapshots(config, selected_entries)
    save_config(config)
    notify('Configuración guardada: {0} canales'.format(len(selected_entries)))
    return True


def _catalog_entry_map(root, config):
    # Los IDs antiguos de variantes ahora apuntan al canal consolidado.
    entries = get_region_channels(root, config.get('region', '')) if config.get('region') else []
    result = {}
    for entry in entries:
        result[entry['id']] = entry
        for alias in entry.get('aliases', []):
            result[alias] = entry

    # Migra selecciones duplicadas de versiones anteriores sin perder canales.
    canonical = []
    seen = set()
    for channel_id in config.get('selected', []):
        entry = result.get(channel_id)
        resolved_id = entry.get('id') if entry else channel_id
        if resolved_id not in seen:
            canonical.append(resolved_id)
            seen.add(resolved_id)
    if canonical != config.get('selected', []):
        config['selected'] = canonical
        try:
            save_config(config)
        except Exception as exc:
            log('No se pudo actualizar la selección al consolidar canales: {0}'.format(exc), xbmc.LOGWARNING)
    return result


_FAST_SERVICE_RE = re.compile(
    r"\b(rakuten(?:\s*tv)?|runtime(?:\s*tv)?|lg\s*channels?|"
    r"samsung\s*tv\s*plus|sam\s*tv\s*plus|pluto\s*tv|plex\s*tv|"
    r"tubi(?:\s*tv)?|freevee|xumo(?:\s*play)?|rlaxx|\bwaipu\b|"
    r"\bthe\s*roku\s*channel\b|\bplex\b)\b", re.I)


def _entry_search_text(entry):
    return clean_display_name(' '.join(
        [entry.get('name', ''), entry.get('original_name', '')] +
        list(entry.get('path') or []) +
        [part for path in entry.get('alternate_paths', []) for part in path] +
        [entry.get('region', '')]
    ))


def _is_fast_service(entry):
    """Detecta canales de plataformas FAST que el usuario pidió ocultar."""
    return bool(_FAST_SERVICE_RE.search(_entry_search_text(entry)))


_CATEGORY_RULES = [
    ('Deportes', re.compile(r'\b(sport|sports|espn|fox\s*sports?|dsports?|dazn|tnt\s*sport|win\s*sport|tyc|gol\s*tv|futbol|fútbol|formula\s*1|ufc|nba|nfl|mlb|wwe|motor)\b', re.I)),
    ('Películas', re.compile(r'\b(cine|cinema|movie|pel[ií]cula|film|hbo|cinemax|paramount\s*channel|studio|amc|universal\s*(?:cinema|premiere)|star\s*channel)\b', re.I)),
    ('Series y entretenimiento', re.compile(r'\b(series|serie|comedy|comed[y]?|comedia|entreten|warner|fox|axn|sony|fx|syfy|e!|tlc|discovery|history|historia|investigation|crime|reality|novela|telenovela)\b', re.I)),
    ('Noticias', re.compile(r'\b(news|noticias|cnn|bbc|ntn|24\s*horas|teleSUR|euronews|france\s*24|dw\s*news|foro\s*tv)\b', re.I)),
    ('Infantiles', re.compile(r'\b(kids|junior|ni[nñ]os|infantil|disney|nick(?:elodeon)?|cartoon|boomerang|baby\s*tv|paka\s*paka)\b', re.I)),
    ('Música', re.compile(r'\b(music|m[uú]sica|mtv|vh1|vevo|concert|concierto|ritmo|telehit|htv)\b', re.I)),
]


def _channel_category(entry):
    text = _entry_search_text(entry)
    for category, pattern in _CATEGORY_RULES:
        if pattern.search(text):
            return category
    return 'General'

def _add_selected_channel(entry, channel_id, selected_count, snapshot=None):
    label = _channel_label(entry)
    context = [
        ('Eliminar de Mis canales', 'RunPlugin({0})'.format(plugin_url('remove', id=channel_id))),
        ('Mover arriba', 'RunPlugin({0})'.format(plugin_url('move', id=channel_id, direction='up'))),
        ('Mover abajo', 'RunPlugin({0})'.format(plugin_url('move', id=channel_id, direction='down'))),
    ]
    item = xbmcgui.ListItem(label=label)
    art = {}
    if entry.get('thumbnail'):
        art.update({'thumb': entry['thumbnail'], 'icon': entry['thumbnail']})
    if entry.get('fanart'):
        art['fanart'] = entry['fanart']
    if art:
        item.setArt(art)
    item.setInfo('video', {'title': label, 'plot': entry.get('info', '')})
    item.setProperty('IsPlayable', 'true')
    item.addContextMenuItems(context)
    xbmcplugin.addDirectoryItem(HANDLE, plugin_url('play', id=channel_id), item, False, selected_count)


def _category_view(root, config, category):
    xbmcplugin.setPluginCategory(HANDLE, category)
    entry_map = _catalog_entry_map(root, config)
    selected = []
    for channel_id in config.get('selected', []):
        entry = entry_map.get(channel_id)
        if entry and not _is_fast_service(entry) and _channel_category(entry) == category:
            selected.append((channel_id, entry))
    for channel_id, entry in selected:
        _add_selected_channel(entry, channel_id, len(selected))
    add_directory('Volver a categorías', plugin_url('home'))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def home(root=None, config=None):
    config = config or load_config()
    if root is None:
        root, _source = load_catalog()
    xbmcplugin.setPluginCategory(HANDLE, 'Mis canales')
    if not config.get('setup_complete'):
        add_directory('Configurar mis canales', plugin_url('wizard'), ADDON.getAddonInfo('icon'))
    else:
        entry_map = _catalog_entry_map(root, config)
        visible = []
        missing = []
        for channel_id in config.get('selected', []):
            entry = entry_map.get(channel_id)
            if entry:
                if not _is_fast_service(entry):
                    visible.append((channel_id, entry))
            else:
                snapshot = config.get('snapshots', {}).get(channel_id, {})
                missing.append((channel_id, snapshot))

        categories = {}
        for channel_id, entry in visible:
            category = _channel_category(entry)
            categories.setdefault(category, []).append((channel_id, entry))

        order = ['Deportes', 'Películas', 'Series y entretenimiento', 'Noticias', 'Infantiles', 'Música', 'General']
        for category in order:
            items = categories.get(category, [])
            if items:
                add_directory('{0} ({1})'.format(category, len(items)),
                              plugin_url('category', name=category), ADDON.getAddonInfo('icon'),
                              description='Canales de la categoría {0}'.format(category))

        # Mantener accesibles las selecciones antiguas que ya no aparecen en catálogo.
        for channel_id, snapshot in missing:
            old_name = snapshot.get('name', 'Canal') + '  [no disponible en el catálogo]'
            item = xbmcgui.ListItem(label=old_name)
            if snapshot.get('thumbnail'):
                item.setArt({'thumb': snapshot['thumbnail'], 'icon': snapshot['thumbnail']})
            item.setInfo('video', {'title': old_name, 'plot': 'Este canal ya no aparece en la versión actual del catálogo. La selección se conserva.'})
            item.addContextMenuItems([('Eliminar de Mis canales', 'RunPlugin({0})'.format(plugin_url('remove', id=channel_id)))])
            xbmcplugin.addDirectoryItem(HANDLE, plugin_url('missing', id=channel_id), item, False)

        hidden_count = len(config.get('selected', [])) - len(visible) - len(missing)
        if hidden_count > 0:
            log('Se ocultaron {0} canales de plataformas FAST'.format(hidden_count))

    add_directory('Administrar canales', plugin_url('manage'), ADDON.getAddonInfo('icon'))
    add_directory('Actualizar catálogo', plugin_url('refresh'), ADDON.getAddonInfo('icon'))
    add_directory('Configuración', plugin_url('settings'), ADDON.getAddonInfo('icon'))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)

def manage(root, config):
    xbmcplugin.setPluginCategory(HANDLE, 'Administrar canales')
    add_directory('Cambiar región y selección', plugin_url('change_region'))
    add_directory('Explorar catálogo general', plugin_url('catalog'))
    add_directory('Buscar canales por nombre', plugin_url('search_catalog'))
    add_directory('Agregar canales de la región actual', plugin_url('add_channels'))
    add_directory('Eliminar canales', plugin_url('remove_select'))
    add_directory('Cambiar orden de canales', plugin_url('reorder'))
    add_directory('Volver a ejecutar el asistente inicial', plugin_url('wizard'))
    add_directory('Volver a Mis canales', plugin_url('home'))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def _catalog_categories(entries):
    groups = {}
    for entry in entries:
        if _is_fast_service(entry):
            continue
        groups.setdefault(_channel_category(entry), []).append(entry)
    order = ['Deportes', 'Películas', 'Series y entretenimiento', 'Noticias', 'Infantiles', 'Música', 'General']
    return [(name, groups[name]) for name in order if groups.get(name)]


def catalog_home(root, config):
    if not config.get('region'):
        xbmcgui.Dialog().ok(ADDON_NAME, 'Primero selecciona una región.')
        return
    entries = get_region_channels(root, config.get('region', ''))
    xbmcplugin.setPluginCategory(HANDLE, 'Catálogo general')
    add_directory('Buscar canales por nombre', plugin_url('search_catalog'))
    for category, items in _catalog_categories(entries):
        add_directory('{0} ({1})'.format(category, len(items)),
                      plugin_url('catalog_category', name=category))
    add_directory('Volver', plugin_url('manage'))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def catalog_category(root, config, category):
    entries = get_region_channels(root, config.get('region', ''))
    chosen = [e for e in entries if not _is_fast_service(e) and _channel_category(e) == category]
    xbmcplugin.setPluginCategory(HANDLE, 'Catálogo general / ' + category)
    for entry in chosen:
        label = _channel_label(entry)
        item = xbmcgui.ListItem(label=label)
        if entry.get('thumbnail'):
            item.setArt({'thumb': entry['thumbnail'], 'icon': entry['thumbnail']})
        item.setInfo('video', {'title': label, 'plot': 'Agregar este canal a Mis canales'})
        item.addContextMenuItems([('Agregar a Mis canales', 'RunPlugin({0})'.format(plugin_url('catalog_add', id=entry['id'])))])
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url('catalog_add', id=entry['id']), item, True)
    add_directory('Buscar en el catálogo', plugin_url('search_catalog'))
    add_directory('Volver al catálogo general', plugin_url('catalog'))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def catalog_search(root, config):
    query = xbmcgui.Dialog().input('Buscar canal por nombre', '')
    if not query:
        catalog_home(root, config)
        return
    needle = clean_display_name(query).casefold()
    entries = get_region_channels(root, config.get('region', ''))
    matches = [e for e in entries if not _is_fast_service(e) and needle in _entry_search_text(e).casefold()]
    xbmcplugin.setPluginCategory(HANDLE, 'Resultados: ' + query)
    for entry in matches:
        label = _channel_label(entry)
        item = xbmcgui.ListItem(label=label)
        if entry.get('thumbnail'):
            item.setArt({'thumb': entry['thumbnail'], 'icon': entry['thumbnail']})
        item.setInfo('video', {'title': label, 'plot': 'Agregar este canal a Mis canales'})
        item.addContextMenuItems([('Agregar a Mis canales', 'RunPlugin({0})'.format(plugin_url('catalog_add', id=entry['id'])))])
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url('catalog_add', id=entry['id']), item, True)
    if not matches:
        add_directory('No se encontraron canales con ese nombre', plugin_url('search_catalog'))
    add_directory('Buscar otra vez', plugin_url('search_catalog'))
    add_directory('Volver al catálogo general', plugin_url('catalog'))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def catalog_add(root, config, channel_id):
    entries = get_region_channels(root, config.get('region', ''))
    entry = next((e for e in entries if e.get('id') == channel_id), None)
    if not entry or _is_fast_service(entry):
        xbmcgui.Dialog().ok(ADDON_NAME, 'Ese canal no está disponible para agregar.')
        return
    entry_map = _catalog_entry_map(root, config)
    canonical_id = entry.get('id')
    selected = list(config.get('selected', []))
    selected_entries = [entry_map.get(item_id) for item_id in selected]
    already_selected = any(item and item.get('id') == canonical_id for item in selected_entries)
    if not already_selected:
        selected.append(canonical_id)
        config['selected'] = selected
        _store_snapshots(config, [entry])
        save_config(config)
        notify('Agregado: ' + _channel_label(entry))
    else:
        notify('Ese canal ya está en Mis canales')


def change_region(root, config):
    region_name = _select_region(root, 'Selecciona la nueva región')
    if not region_name:
        return
    if not xbmcgui.Dialog().yesno(ADDON_NAME,
            'Cambiar a "{0}" reemplazará la selección de canales actual. ¿Continuar?'.format(region_name)):
        return
    entries = get_region_channels(root, region_name)
    selected = _select_channel_ids(entries, 'Selecciona los canales de la nueva región')
    if selected is None:
        return
    selected_set = set(selected)
    chosen = [e for e in entries if e['id'] in selected_set]
    if not _confirm_selection(region_name, chosen):
        return
    config['region'] = region_name
    config['selected'] = [e['id'] for e in chosen]
    config['setup_complete'] = True
    _store_snapshots(config, chosen)
    save_config(config)
    notify('Región y canales actualizados')


def add_channels(root, config):
    region_name = config.get('region')
    if not region_name:
        return change_region(root, config)
    entries = get_region_channels(root, region_name)
    selected = _select_channel_ids(entries, 'Agregar o ajustar canales', config.get('selected', []))
    if selected is None:
        return
    chosen_set = set(selected)
    chosen = [entry for entry in entries if entry['id'] in chosen_set]
    config['selected'] = [entry['id'] for entry in chosen]
    _store_snapshots(config, chosen)
    config['setup_complete'] = True
    save_config(config)
    notify('Selección guardada')


def remove_channels(config, ids=None):
    current = list(config.get('selected', []))
    if ids is None:
        if not current:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No hay canales seleccionados.')
            return
        names = []
        for channel_id in current:
            snap = config.get('snapshots', {}).get(channel_id, {})
            label = snap.get('name', 'Canal')
            if snap.get('zone'):
                label += ' — ' + snap['zone']
            names.append(label)
        indexes = xbmcgui.Dialog().multiselect('Selecciona los canales que deseas eliminar', names)
        if indexes is None:
            return
        ids = [current[i] for i in indexes if 0 <= i < len(current)]
    remove_set = set(ids)
    config['selected'] = [channel_id for channel_id in current if channel_id not in remove_set]
    save_config(config)
    notify('Canales eliminados')


def move_channel(config, channel_id, direction):
    selected = list(config.get('selected', []))
    if channel_id not in selected:
        return
    index = selected.index(channel_id)
    target = index - 1 if direction == 'up' else index + 1
    if target < 0 or target >= len(selected):
        return
    selected[index], selected[target] = selected[target], selected[index]
    config['selected'] = selected
    save_config(config)


def refresh_catalog():
    try:
        root, source = load_catalog(force=True)
        regions = list_regions(root)
        # No descargar todas las listas externas en segundo plano; se refrescan
        # al entrar en cada región y se mantienen sus cachés por separado.
        if source == 'remote':
            # Solo invalidar sublistas cuando se confirmó una descarga nueva.
            # Si la actualización falla, conservar también las cachés externas.
            try:
                if os.path.isdir(SOURCE_CACHE_DIR):
                    shutil.rmtree(SOURCE_CACHE_DIR)
            except Exception as cache_exc:
                log('No se pudo limpiar caché externa tras actualizar: {0}'.format(cache_exc), xbmc.LOGWARNING)
            notify('Catálogo actualizado: {0} regiones originales'.format(len(regions)), 6000)
        else:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo descargar una versión nueva. Se conserva el catálogo local y sus listas guardadas.')
        return root
    except Exception as exc:
        log('Error al actualizar catálogo: {0}'.format(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo actualizar el catálogo.', str(exc))
        return None


def settings_menu():
    xbmcplugin.setPluginCategory(HANDLE, 'Configuración')
    add_directory('Abrir preferencias de reproducción', plugin_url('open_settings'))
    add_directory('Borrar caché del catálogo', plugin_url('clear_catalog_cache'))
    add_directory('Borrar caché de fuentes', plugin_url('clear_source_cache'))
    add_directory('Restaurar configuración inicial', plugin_url('reset'))
    add_directory('Volver a Mis canales', plugin_url('home'))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def _expand_sources(entry):
    # Las carpetas externallink se resuelven antes, al construir el catálogo.
    # Aquí solo se devuelven las fuentes pertenecientes a este canal/variante.
    unique = []
    markers = set()
    for source in entry.get('sources', []):
        key = (source.get('kind'), source.get('url'))
        if key not in markers:
            markers.add(key)
            unique.append(source)
    return unique


def play_channel(root, config, channel_id):
    entry_map = _catalog_entry_map(root, config)
    entry = entry_map.get(channel_id)
    if not entry:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Este canal ya no aparece en el catálogo actual.')
        return
    sources = _expand_sources(entry)
    if not sources:
        xbmcgui.Dialog().ok(ADDON_NAME, 'El canal no contiene fuentes que se puedan reproducir.')
        return

    # La reproducción ahora prueba automáticamente las fuentes alternativas.
    # No se muestra un selector manual, incluso si quedó una preferencia vieja.

    try:
        # Construir la secuencia en el orden de 'Mis canales'. Así Kodi puede
        # cambiar de canal con PlayerControl(Next/Previous) sin salir del video.
        selected_entries = []
        for selected_id in config.get('selected', []):
            selected_entry = entry_map.get(selected_id)
            if selected_entry and not _is_fast_service(selected_entry):
                selected_sources = _expand_sources(selected_entry)
                if selected_sources:
                    selected_entries.append({
                        'name': _channel_label(selected_entry),
                        'thumbnail': selected_entry.get('thumbnail', ''),
                        'sources': selected_sources,
                    })
        start_index = 0
        for i, selected_id in enumerate(config.get('selected', [])):
            if selected_id == channel_id:
                # El índice se recalcula en la lista realmente reproducible.
                target_name = _channel_label(entry)
                for j, channel in enumerate(selected_entries):
                    if channel.get('name') == target_name:
                        start_index = j
                        break
                break
        if selected_entries:
            play_channel_sequence(
                selected_entries, start_index=start_index,
                notify=(ADDON.getSetting('show_notifications') != 'false'))
        else:
            play_sources(
                _channel_label(entry), entry.get('thumbnail', ''), sources,
                auto_retry=(ADDON.getSetting('auto_retry') != 'false'),
                notify=(ADDON.getSetting('show_notifications') != 'false'),
            )
    except Exception as exc:
        log('No fue posible reproducir {0}: {1}'.format(entry.get('name'), exc), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo reproducir este canal.', str(exc))
    finally:
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        except Exception:
            pass


def route():
    params = urllib.parse.parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 and sys.argv[2] else {}
    action = params.get('action', ['home'])[0]
    config = load_config()

    if action in ('play', 'missing'):
        try:
            root, _source = load_catalog()
        except Exception as exc:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo abrir el catálogo para reproducir.', str(exc))
            return
        if action == 'play':
            play_channel(root, config, params.get('id', [''])[0])
        return

    # Las acciones de mantenimiento y preferencias no dependen de que el
    # servidor del catálogo esté disponible.
    if action == 'settings':
        settings_menu()
        return
    if action == 'open_settings':
        ADDON.openSettings()
        settings_menu()
        return
    if action == 'clear_catalog_cache':
        try:
            if os.path.exists(CACHE_FILE):
                os.remove(CACHE_FILE)
            notify('Caché del catálogo eliminada')
        except Exception as exc:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo borrar la caché.', str(exc))
        settings_menu()
        return
    if action == 'clear_source_cache':
        try:
            if os.path.isdir(SOURCE_CACHE_DIR):
                shutil.rmtree(SOURCE_CACHE_DIR)
            notify('Caché de listas externas eliminada')
        except Exception as exc:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo borrar la caché de fuentes.', str(exc))
        settings_menu()
        return
    if action in ('catalog', 'catalog_category', 'search_catalog', 'catalog_add'):
        try:
            root, _source = load_catalog()
            if action == 'catalog':
                catalog_home(root, config)
            elif action == 'catalog_category':
                catalog_category(root, config, params.get('name', ['General'])[0])
            elif action == 'search_catalog':
                catalog_search(root, config)
            else:
                catalog_add(root, config, params.get('id', [''])[0])
                # Mantener al usuario dentro del catálogo tras agregar.
                catalog_home(root, load_config())
        except Exception as exc:
            log('Error en catálogo general: {0}'.format(exc), xbmc.LOGERROR)
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo abrir el catálogo general.', str(exc))
        return

    if action == 'category':
        try:
            root, _source = load_catalog()
            _category_view(root, config, params.get('name', ['General'])[0])
        except Exception as exc:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo abrir la categoría.', str(exc))
        return

    if action == 'refresh':
        updated_root = refresh_catalog()
        if updated_root is not None:
            home(updated_root, load_config())
        else:
            xbmcplugin.setPluginCategory(HANDLE, 'Magellan AutoPlay')
            add_directory('Reintentar actualizar catálogo', plugin_url('refresh'))
            add_directory('Configuración', plugin_url('settings'))
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return

    # Home intenta cargar la copia local primero; si no existe, descarga el
    # mismo catálogo fuente usado por Magellan.
    try:
        root, _source = load_catalog()
    except Exception as exc:
        log('No se pudo cargar catálogo: {0}'.format(exc), xbmc.LOGERROR)
        xbmcplugin.setPluginCategory(HANDLE, 'Magellan AutoPlay')
        add_directory('Reintentar cargar catálogo', plugin_url('refresh'))
        add_directory('Configuración', plugin_url('settings'))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        if action == 'home':
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo leer el catálogo original de Magellan.', str(exc))
        return

    if action == 'home':
        if not config.get('setup_complete'):
            # Solo se muestra el asistente automáticamente en la primera
            # apertura; si se cancela, la opción permanece en la pantalla.
            if run_wizard(root, config):
                config = load_config()
        home(root, config)
    elif action == 'wizard':
        run_wizard(root, config)
        home(root, load_config())
    elif action == 'manage':
        manage(root, config)
    elif action == 'change_region':
        change_region(root, config)
        home(root, load_config())
    elif action == 'add_channels':
        add_channels(root, config)
        home(root, load_config())
    elif action == 'remove_select':
        remove_channels(config)
        home(root, load_config())
    elif action == 'remove':
        remove_channels(config, [params.get('id', [''])[0]])
        home(root, load_config())
    elif action == 'move':
        move_channel(config, params.get('id', [''])[0], params.get('direction', ['up'])[0])
        home(root, load_config())
    elif action == 'reorder':
        current = config.get('selected', [])
        labels = []
        for channel_id in current:
            snap = config.get('snapshots', {}).get(channel_id, {})
            labels.append(snap.get('name', 'Canal'))
        index = xbmcgui.Dialog().select('Selecciona el canal que quieres mover', labels)
        if index >= 0:
            direction = xbmcgui.Dialog().select('Mover canal', ['Mover arriba', 'Mover abajo'])
            if direction >= 0 and index < len(current):
                move_channel(config, current[index], 'up' if direction == 0 else 'down')
        home(root, load_config())
    elif action == 'reset':
        if xbmcgui.Dialog().yesno(ADDON_NAME, '¿Borrar la selección y volver a ejecutar el asistente?'):
            config['setup_complete'] = False
            config['region'] = ''
            config['selected'] = []
            save_config(config)
            run_wizard(root, config)
        home(root, load_config())
    else:
        home(root, config)


if __name__ == '__main__':
    try:
        route()
    except Exception as exc:
        log('Error no controlado: {0}\n{1}'.format(exc, traceback.format_exc()), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, 'Se produjo un error. Revisa kodi.log.', str(exc))
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        except Exception:
            pass
