# -*- coding: utf-8 -*-
"""Prueba y reproduce fuentes usando los callbacks reales de Kodi."""
from __future__ import absolute_import, unicode_literals

import time
import re
import html
import uuid
import urllib.request
import urllib.parse
import xbmc
import xbmcgui


class SourcePlayer(xbmc.Player):
    def __init__(self):
        super(SourcePlayer, self).__init__()
        self.state = 'idle'
        self.state_time = time.time()

    def reset_state(self):
        self.state = 'idle'
        self.state_time = time.time()

    def onPlayBackStarted(self):
        self.state = 'started'
        self.state_time = time.time()
        # Intenta cerrar el indicador de espera de Kodi cuando el reproductor
        # confirma que el video ya comenzó. El skin puede ignorar este cierre.
        try:
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        except Exception:
            pass

    def onPlayBackError(self):
        self.state = 'error'
        self.state_time = time.time()

    def onPlayBackStopped(self):
        self.state = 'stopped'
        self.state_time = time.time()

    def onPlayBackEnded(self):
        self.state = 'ended'
        self.state_time = time.time()


def _make_list_item(name, thumbnail, source):
    item = xbmcgui.ListItem(label=name)
    if thumbnail:
        item.setArt({'thumb': thumbnail, 'icon': thumbnail})
    url = source.get('url', '')
    kind = source.get('kind', 'direct')
    if kind == 'inputstream':
        # Mantener el enlace original. Solo se configuran propiedades cuando
        # la extensión indica explícitamente el uso de InputStream Adaptive.
        if '.m3u8' in url.lower():
            item.setProperty('inputstream', 'inputstream.adaptive')
            item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            item.setMimeType('application/vnd.apple.mpegurl')
            item.setContentLookup(False)
        elif '.mpd' in url.lower() or 'format=mpd' in url.lower():
            item.setProperty('inputstream', 'inputstream.adaptive')
            item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            item.setMimeType('application/dash+xml')
            item.setContentLookup(False)
        elif '.ism' in url.lower():
            item.setProperty('inputstream', 'inputstream.adaptive')
            item.setProperty('inputstream.adaptive.manifest_type', 'ism')
            item.setMimeType('application/vnd.ms-sstr+xml')
            item.setContentLookup(False)
    if '$$lic=' in url:
        try:
            _base, license_key = url.split('$$lic=', 1)
            item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
            item.setProperty('inputstream.adaptive.license_key', license_key)
        except Exception:
            pass
    if '|' in url:
        try:
            _base, headers = url.split('|', 1)
            item.setProperty('inputstream.adaptive.stream_headers', headers)
        except Exception:
            pass
    item.setProperty('IsPlayable', 'true')
    return item


def _resolve_doregex(source):
    """Resuelve expresiones $doregex simples del XML sin ejecutar Python remoto."""
    url = source.get('url', '')
    regexes = dict((entry.get('name'), entry) for entry in source.get('regexes', []) if entry.get('name'))
    if '$doregex[' not in url:
        return source
    for _attempt in range(12):
        match = re.search(r'\$doregex\[([^\]]+)\]', url)
        if not match:
            break
        key = match.group(1)
        definition = regexes.get(key)
        if not definition:
            raise RuntimeError('Falta la definición regex "{0}" en el catálogo'.format(key))
        page = definition.get('page', '') or ''
        expression = definition.get('expres', '') or ''
        if '$doregex[' in page:
            nested = dict(source)
            nested['url'] = page
            page = _resolve_doregex(nested).get('url', '')
        if page.startswith('$pyFunction:') or expression.startswith('$pyFunction:') or '#$pyFunction' in expression:
            raise RuntimeError('Esta fuente requiere una función dinámica de Magellan que no se ejecuta desde código remoto')
        content = ''
        if page.startswith('http://') or page.startswith('https://'):
            headers = {'User-Agent': definition.get('agent') or
                       'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36'}
            header_part = ''
            if '|' in page:
                page, header_part = page.split('|', 1)
            for field, header in (('referer', 'Referer'), ('accept', 'Accept'),
                                  ('origin', 'Origin'), ('x-req', 'X-Requested-With'),
                                  ('x-addr', 'x-addr'), ('x-forward', 'X-Forwarded-For')):
                if definition.get(field):
                    headers[header] = definition[field]
            if header_part:
                for pair in header_part.split('&'):
                    if '=' in pair:
                        name, value = pair.split('=', 1)
                        headers[name] = value
            request = urllib.request.Request(page, headers=headers)
            post = None
            if definition.get('rawpost'):
                post = definition['rawpost'].encode('utf-8')
            elif definition.get('post'):
                post_values = {}
                for pair in definition['post'].split(','):
                    if ':' in pair:
                        name, value = pair.split(':', 1)
                        post_values[name] = value
                if post_values:
                    post = urllib.parse.urlencode(post_values).encode('utf-8')
            with urllib.request.urlopen(request, data=post, timeout=20) as response:
                raw = response.read()
                charset = None
                content_type = response.headers.get('Content-Type', '')
                charset_match = re.search(r'charset=([^; ]+)', content_type, re.I)
                if charset_match:
                    charset = charset_match.group(1).strip('"\'')
            content = raw.decode(charset or 'utf-8', 'replace')
        else:
            content = page
        if not page:
            # Magellan usa expres como enlace literal cuando no hay etiqueta page.
            value = expression
        elif not expression:
            value = content
        else:
            try:
                found = re.search(expression, content, re.S)
                value = found.group(1).strip() if found else ''
            except re.error as exc:
                raise RuntimeError('Expresión regex no válida ({0}): {1}'.format(key, exc))
        if definition.get('htmlunescape'):
            value = html.unescape(value)
        if not value:
            raise RuntimeError('La expresión "{0}" no devolvió una fuente'.format(key))
        url = url.replace(match.group(0), value)
    if '$doregex[' in url:
        raise RuntimeError('Demasiados niveles de expresiones regex')
    url = url.replace('$epoctime$', str(int(time.time())))
    url = url.replace('$GUID$', str(uuid.uuid1()).upper())
    result = dict(source)
    result['url'] = url
    return result


def _resolve_special(source):
    """Resuelve tipos especiales solo si el módulo opcional existe."""
    source = _resolve_doregex(source)
    kind = source.get('kind', 'direct')
    url = source.get('url', '')
    if kind == 'urlsolve':
        last_error = None
        try:
            import resolveurl
            resolved = resolveurl.resolve(url)
            if resolved:
                return {'url': resolved, 'kind': 'direct'}
        except Exception as exc:
            last_error = exc
        try:
            import urlresolver
            resolved = urlresolver.resolve(url)
            if resolved:
                return {'url': resolved, 'kind': 'direct'}
        except Exception as exc:
            last_error = exc
        raise RuntimeError('No se pudo resolver el enlace: {0}'.format(last_error or 'resolver no disponible'))
    if kind == 'slproxy':
        # La implementación de SLProxy puede variar según la versión del
        # módulo. Se intenta usar su helper de Magellan cuando está instalado.
        try:
            from dsp import streamlink_proxy
            helper = streamlink_proxy.SLProxy_Helper()
            if '$$RESOLVEONLY$$' in url:
                url = url.replace('$$RESOLVEONLY$$', '')
                q = ''
                if '$$QUALITY=' in url:
                    q = url.split('$$QUALITY=', 1)[1].split('$$', 1)[0]
                    url = url.replace('$$QUALITY=' + q + '$$', '')
                resolved = helper.resolve_url(url if not q else url + '&q=' + q)
                if resolved:
                    return {'url': resolved, 'kind': 'direct'}
            raise RuntimeError('La fuente SLProxy requiere el reproductor del módulo')
        except Exception as exc:
            raise RuntimeError('SLProxy no está disponible o no pudo resolver la fuente: {0}'.format(exc))
    if kind in ('dm', 'dmlive', 'utube', 'sportsdevil'):
        if url.startswith('plugin://'):
            return {'url': url, 'kind': 'plugin'}
        if kind == 'dm':
            return {'url': 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=' + urllib.parse.quote(url, safe=''), 'kind': 'plugin'}
        if kind == 'dmlive':
            return {'url': 'plugin://plugin.video.dailymotion_com/?mode=playLiveVideo&url=' + urllib.parse.quote(url, safe=''), 'kind': 'plugin'}
        if kind == 'utube':
            if ' ' in url:
                target = 'plugin://plugin.video.youtube/search/?q=' + urllib.parse.quote_plus(url)
            elif len(url) == 11:
                target = 'plugin://plugin.video.youtube/play/?video_id=' + url
            elif url.startswith(('PL', 'UU')):
                target = 'plugin://plugin.video.youtube/play/?playlist_id=' + url
            elif url.startswith('UC') and len(url) > 12:
                target = 'plugin://plugin.video.youtube/channel/' + url + '/'
            else:
                target = 'plugin://plugin.video.youtube/user/' + url + '/'
            return {'url': target, 'kind': 'plugin'}
        if kind == 'sportsdevil':
            target = ('plugin://plugin.video.sportsdevil/?mode=1&item=catcher%3dstreams%26url=' +
                      urllib.parse.quote(url, safe='') + '%26videoTitle=' + urllib.parse.quote('Magellan', safe=''))
            return {'url': target, 'kind': 'plugin'}
        raise RuntimeError('El elemento requiere un complemento externo no disponible')
    if kind == 'youtube-dl':
        try:
            import youtube_dl
            info = youtube_dl.YoutubeDL({'quiet': True, 'no_warnings': True}).extract_info(url, download=False)
            if info and info.get('url'):
                return {'url': info['url'], 'kind': 'direct'}
        except Exception as exc:
            raise RuntimeError('No se pudo resolver con YouTube-DL: {0}'.format(exc))
        raise RuntimeError('YouTube-DL no devolvió un enlace')
    return source


def play_sources(name, thumbnail, sources, auto_retry=True, notify=True, startup_timeout=25):
    """Intenta cada fuente. Kodi confirma el arranque mediante callbacks.

    Después de iniciar, solo un callback onPlayBackError dispara el siguiente
    enlace. onPlayBackStopped se interpreta como una parada solicitada por el
    usuario y no provoca un bucle de reproducción.
    """
    player = SourcePlayer()
    monitor = xbmc.Monitor()
    if not sources:
        raise RuntimeError('Este canal no contiene fuentes reproducibles.')

    queue = list(sources)
    index = 0
    last_error = ''
    while index < len(queue):
        source = queue[index]
        index += 1
        try:
            source = _resolve_special(source)
            url = source.get('url', '')
            if '$$LSDirect$$' in url:
                url = url.replace('$$LSDirect$$', '')
                source = dict(source)
                source['url'] = url
            if not url:
                raise RuntimeError('Fuente vacía')
            try:
                if player.isPlaying():
                    player.stop()
                    xbmc.sleep(250)
            except Exception:
                pass
            player.reset_state()
            list_item = _make_list_item(name, thumbnail, source)
            if '$$lic=' in url:
                # La licencia ya viaja en las propiedades del ListItem.
                url = url.split('$$lic=', 1)[0]
            xbmc.log('[Magellan AutoPlay] Probando fuente {0}/{1} de {2}'.format(
                index, len(queue), name), xbmc.LOGINFO)
            player.play(url, list_item)

            start = time.time()
            while not monitor.abortRequested():
                state = player.state
                if state == 'started' or player.isPlaying():
                    break
                if state in ('error', 'stopped', 'ended'):
                    raise RuntimeError('Kodi no pudo iniciar la fuente')
                if time.time() - start >= startup_timeout:
                    raise RuntimeError('Tiempo de espera agotado al iniciar la fuente')
                xbmc.sleep(250)

            if monitor.abortRequested():
                return True

            # Mantener vivo el proceso mientras Kodi reproduce para poder
            # reaccionar a onPlayBackError y probar la siguiente fuente.
            last_active = time.time()
            while not monitor.abortRequested():
                state = player.state
                if state == 'error':
                    raise RuntimeError('Kodi notificó un error durante la reproducción')
                if state in ('stopped', 'ended'):
                    return True
                if player.isPlaying():
                    last_active = time.time()
                elif state == 'started' and time.time() - last_active > 5:
                    raise RuntimeError('La reproducción se interrumpió sin un callback de finalización')
                xbmc.sleep(500)
            return True
        except Exception as exc:
            last_error = str(exc)
            xbmc.log('[Magellan AutoPlay] Fuente {0} falló: {1}'.format(index, last_error), xbmc.LOGWARNING)
            try:
                player.stop()
            except Exception:
                pass
            if not auto_retry:
                break
            if notify:
                xbmcgui.Dialog().notification('Magellan AutoPlay',
                    'La fuente falló. Probando otra...', time=2500)

    raise RuntimeError('No se pudo iniciar ninguna de las {0} fuentes. {1}'.format(
        len(sources), last_error))



def play_channel_sequence(channels, start_index=0):
    """Reproduce la selección en una lista de Kodi; Next/Previous cambian de canal."""
    if not channels:
        raise RuntimeError('No hay canales seleccionados para reproducir.')
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    playable = []
    for channel in channels:
        name = channel.get('name') or 'Canal'
        thumbnail = channel.get('thumbnail', '')
        sources = channel.get('sources') or []
        if not sources:
            continue
        last_error = None
        resolved = None
        # Cada canal aporta su primera fuente disponible. Los canales que no
        # pueden resolverse se omiten sin interrumpir la lista.
        for candidate in sources:
            try:
                resolved = _resolve_special(candidate)
                if resolved and resolved.get('url'):
                    break
            except Exception as exc:
                last_error = exc
                resolved = None
        if not resolved:
            xbmc.log('[Magellan AutoPlay] Canal omitido {0}: {1}'.format(name, last_error), xbmc.LOGWARNING)
            continue
        url = resolved.get('url', '')
        if '$$LSDirect$$' in url:
            url = url.replace('$$LSDirect$$', '')
        if '$$lic$$' in url:
            url = url.split('$$lic$$', 1)[0]
        item = _make_list_item(name, thumbnail, resolved)
        playlist.add(url, item)
        playable.append(name)

    if not playable:
        raise RuntimeError('No se pudo preparar ninguna fuente de los canales seleccionados.')
    start_index = max(0, min(int(start_index), len(playable) - 1))
    player = SourcePlayer()
    monitor = xbmc.Monitor()
    try:
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        player.play(playlist, startpos=start_index)
        started_at = time.time()
        while not monitor.abortRequested():
            if player.state == 'error':
                raise RuntimeError('Kodi notificó un error durante la reproducción.')
            if player.state in ('stopped', 'ended'):
                return True
            if player.isPlaying():
                break
            if time.time() - started_at > 30:
                raise RuntimeError('Tiempo de espera agotado al iniciar la lista de canales.')
            xbmc.sleep(250)
        # El proceso permanece activo hasta que el usuario detenga la lista.
        while not monitor.abortRequested():
            if player.state in ('stopped', 'ended'):
                return True
            xbmc.sleep(500)
        return True
    finally:
        try:
            xbmcplugin = None
        except Exception:
            pass
