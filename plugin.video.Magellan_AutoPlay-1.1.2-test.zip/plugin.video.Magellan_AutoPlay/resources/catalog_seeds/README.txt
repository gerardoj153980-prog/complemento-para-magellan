Copias de respaldo aportadas para referencias exactas del catálogo Magellan.

magellan.txt -> catálogo principal (GitLab raw / magellan.txt)
espanhalatinos.txt -> https://pastebin.com/raw/5jZTyKZP
canaleslatinos.txt -> https://pastebin.com/raw/7kQZWCGu
canaleslatinosvariaslistas.txt -> https://pastebin.com/raw/9X2F1NX8

No existe copia local de https://pastebin.com/raw/2tumQ2XE (CANALES ESPAÑA).
No se crean canales ni regiones para sustituir esa lista ausente.
