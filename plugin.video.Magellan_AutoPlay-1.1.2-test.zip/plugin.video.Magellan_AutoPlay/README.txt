MAGELLAN AUTOPLAY 1.1.0

Complemento independiente para Kodi, basado en la estructura del catálogo
original de Magellan Matrix. No sobrescribe plugin.video.Magellan_Matrix.

FUNCIONES
- Conserva las 10 regiones que aparecen en el archivo magellan.txt incluido.
- Sigue externallink de carpetas y sublistas respetando el orden original.
- Primera configuración por región, selección múltiple y confirmación resumida.
- Guarda región, canales, orden y datos básicos de los canales en el perfil Kodi.
- Pantalla principal limitada a los canales seleccionados.
- Administración de canales y actualización del catálogo.
- Lee XML con BOM, referencias inválidas y determinados errores de balanceo.
- Lee listas M3U, mantiene las 12 agrupaciones de LISTA 1 a LISTA 12 del
  archivo proporcionado y conserva atributos tvg-* y encabezados HTTP
  explícitos (#EXTVLCOPT y #EXTHTTP).
- Distingue países y zonas cuando están escritos explícitamente en el título
  o en metadatos. No interpreta identificadores de proveedor/canal como zonas.
- Reproduce fuentes mediante Kodi e intenta la siguiente ante errores de
  inicio o callback onPlayBackError.
- Mantiene enlaces plugin://, parámetros, encabezados y tipos originales.

COPIAS LOCALES INCLUIDAS
Se incluyen las cuatro copias que aportó el usuario como respaldo del catálogo:
- magellan.txt
- espanhalatinos.txt
- canaleslatinos.txt
- canaleslatinosvariaslistas.txt

La copia principal conserva las 10 regiones originales. Las listas locales
permiten reconstruir el recorrido ESPANHA/LATINOS -> CANALES LATINOS ->
Canales Latinos (Várias listas), incluidas las 12 listas M3U. En la prueba
local se obtuvieron 1,723 entradas seleccionables de esta rama; 1,644 tienen
al menos una fuente y 79 no contienen un enlace reproducible en la copia.

LIMITACIÓN DE LAS COPIAS RECIBIDAS
El archivo espanhalatinos.txt es un índice: apunta a una lista separada de
CANALES ESPAÑA (2tumQ2XE) y a la lista CANALES LATINOS (7kQZWCGu). No se
proporcionó el contenido de la lista 2tumQ2XE. Por eso, sin conexión, esta
versión puede reconstruir la rama latina, pero no inventa los canales de
España que faltan. Con conexión, intentará cargar la lista original remota.
Las demás regiones también se muestran exactamente como aparecen en el
catálogo principal y se cargarán desde sus referencias remotas cuando estén
disponibles; sus listas secundarias no están incluidas en este paquete.

REPRODUCCIÓN Y LÍMITES
Kodi confirma el inicio a través de su reproductor. Los callbacks de error
permiten probar otra fuente. Kodi no diferencia siempre una detención manual
de una detención inesperada del flujo; por eso una detención normal no activa
un cambio automático que pudiera impedir al usuario salir del canal.
Algunas fuentes Magellan requieren complementos opcionales, funciones regex
dinámicas o módulos externos. Se conservan sus referencias y se intenta
resolver las modalidades compatibles; no se ejecutan funciones Python
remotas del catálogo.

COMPATIBILIDAD
Diseñado para Kodi 19 o posterior (Python 3).

INSTALACIÓN
1. Kodi > Add-ons > Instalar desde archivo ZIP.
2. Seleccionar plugin.video.Magellan_AutoPlay-1.1.0.zip.
3. Abrir Magellan AutoPlay y completar el asistente inicial.

El catálogo principal usa la misma URL que el complemento Magellan entregado:
https://gitlab.com/afonsocosta/magellan_matrix/-/raw/main/magellan.txt
